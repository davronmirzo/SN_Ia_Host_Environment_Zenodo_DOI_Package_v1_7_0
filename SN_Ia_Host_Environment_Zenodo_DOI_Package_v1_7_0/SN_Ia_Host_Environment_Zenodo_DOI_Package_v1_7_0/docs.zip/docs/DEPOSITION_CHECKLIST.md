# Zenodo deposition checklist - v1.6.0

1. Create a **new version** under concept DOI `10.5281/zenodo.21495899`.
2. Reserve the new exact-version DOI; do not reuse v1.5.0 DOI
   `10.5281/zenodo.21495900`.
3. Insert the reserved DOI:

   ```bash
   python checks/set_reserved_doi.py 10.5281/zenodo.XXXXXXX
   ```

4. Confirm that `python checks/verify_release.py` passes.
5. Confirm that the uploaded ZIP SHA-256 matches the supplied checksum.
6. Use version `1.6.0` and describe the validated fixed-edge
   forward-selection rerun in the Zenodo change log.
7. After publication, replace the manuscript Data Availability DOI with the new
   exact-version DOI and recompile the manuscript.
8. Keep the concept DOI only as the all-versions identifier.

- [ ] Confirm archived v1.5.0 files remain only under `archive/` and are not cited as current results.
- [ ] Reserve a new exact-version DOI for v1.7.0; do not reuse the v1.5.0 exact DOI.
- [ ] Run the figure-only script and visually confirm bold axis typography in Figure 4.
