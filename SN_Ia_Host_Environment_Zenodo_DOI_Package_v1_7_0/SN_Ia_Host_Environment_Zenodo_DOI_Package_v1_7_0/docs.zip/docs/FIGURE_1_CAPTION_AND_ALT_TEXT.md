# Figure 1 caption and alt text

## Caption

Correction-validity workflow used in this study. The validated ZTF residual
layer provides the primary global, redshift-stability, observation-level
influence, and environmental inference, while the broader ZTF raw-to-final
layer is used only for empirical selection-forward simulations and positive-
control tests. Pantheon+ and DES-SN5YR support reduced product-level robustness
and common-support diagnostics. The workflow separates secure detection of a
host residual from validation of a transferable scalar correction and combines
redshift, selection, influence, environmental, and external-product evidence in
the final interpretation.

## Alt text

Flow diagram linking three input layers to five analysis branches. The
validated ZTF residual layer feeds the global, redshift-stability,
observation-level influence, and environmental analyses; the broader ZTF layer
feeds the selection-forward tests; Pantheon+ and DES-SN5YR feed the external-
product audit. The final box states that the ZTF host residual is securely
detected, projected host offset adds structure, and no stable survey-universal
redshift correction is validated.
