# Version lineage and consolidation policy

## Published v1.5.0

- Exact DOI: `10.5281/zenodo.21495900`
- Concept DOI: `10.5281/zenodo.21495899`
- Role: first published reproducibility release.
- Limitation corrected later: its selection-forward branch used an earlier
  harmonized tomography reference.

## Corrected v1.6.0 build

- Role: validated-layer forward-selection rerun using the canonical 2642-object
  residual layer, current fixed five-bin edges, residual-scale WLS covariance,
  and the 250 km s^-1 peculiar-velocity convention.
- Status: intermediate corrected build incorporated into this consolidated
  release.

## Consolidated v1.7.0

This package is the set union of v1.5.0 and v1.6.0 with the following conflict
policy:

1. v1.6.0 files take precedence whenever a relative path changed.
2. Files unique to v1.5.0 that were scientifically superseded are preserved
   only under `archive/v1_5_0_superseded_selection_forward/`.
3. Canonical results, figures, metadata, and claims use the validated v1.6.0
   analysis convention.
4. Figure 4 uses the same frozen v1.6.0 draws and numerical values, with larger
   bold axis typography; no scientific values changed.
5. The consolidated release requires a new exact-version DOI. The concept DOI
   remains `10.5281/zenodo.21495899`.

Archived files are retained for provenance and historical comparison, not for
current inference.
