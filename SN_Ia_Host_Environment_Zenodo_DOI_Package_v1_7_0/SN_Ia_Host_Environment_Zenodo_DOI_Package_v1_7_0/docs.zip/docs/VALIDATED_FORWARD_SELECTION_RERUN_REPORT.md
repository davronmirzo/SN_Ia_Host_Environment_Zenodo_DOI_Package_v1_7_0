# Validated-layer forward-selection rerun

- Validated residual rows: 2642
- Regression-eligible parent rows: 3050
- Expected selected denominator after intercept calibration: 2642.000000
- Fixed observed tomography slope: 1.502655
- Fixed observed Q: 10.613654
- Peculiar-velocity convention: 250 km/s

## Three-scenario forward audit

### zero_mass_effect
- simulations: 300
- median Q: 3.141534
- Q >= observed: 10/300
- leading-one exceedance: 0.036545

### constant_official_mass_step
- simulations: 300
- median Q: 3.295610
- Q >= observed: 8/300
- leading-one exceedance: 0.029900

### observed_validated_tomographic_mass_step
- simulations: 300
- median Q: 15.418725
- Q >= observed: 239/300
- leading-one exceedance: 0.797342

## Global zero-host audit

- simulations: 3000
- median recovered step: -0.002377 mag
- as negative as observed: 0/3000
- leading-one probability: 0.000333222

## Offset positive control

- inserted interaction: +0.234155
- median recovered interaction: +0.232653
- positive-sign recovery fraction: 1.000000

Status: PASS