# Provenance and scope

This release starts from processed object-level survey products:

- a validated 2642-object ZTF DR2 residual layer;
- a 559-object Pantheon+ comparison layer;
- a corrected 1829-object DES-SN5YR Hubble-diagram layer;
- a deduplicated ZTF raw-to-final selection-training layer.

The archive contains the downstream statistical audits and their
machine-readable outputs. It does not reconstruct upstream cadence,
detection, targeting, classification, host-association, survey ingestion, or
collaboration-level bias-correction pipelines.

The ZTF residual layer was identified from upstream pipeline provenance and
then checked by reproducing the reference global host-mass coefficient.
Alternative diagnostic residual layers are retained only for response-layer
validation.

Pantheon+ and DES-SN5YR permit product-level host-mass and tomography
estimation. They do not provide the raw parent-to-final inclusion structure
or directly equivalent local-environment fields required for the complete
ZTF selection-forward and environmental protocol. The release therefore
includes every externally identifiable reduced audit while preserving the
distinction between coefficient estimation and selection-process
reconstruction.


## Version 1.6.0 validated forward-selection provenance

The forward-selection response generator is anchored to the 2642-object
validated residual layer. Fixed redshift edges, observed bin-local steps,
standardized residual pools, and primary WLS conventions all come from that
layer. The broader raw-to-final table contributes parent covariates and the
empirical ridge-logistic selection odds. A single intercept-only probability
calibration conditions the odds on regression eligibility and matches the
expected selected denominator to 2642 without changing fitted odds ratios or
rank ordering. The exact settings are frozen in
`docs/VALIDATED_FORWARD_SELECTION_RERUN_CONFIG.json`.

## Consolidation provenance

The v1.7.0 tree was formed by taking v1.6.0 as the canonical base, retaining the v1.6.0 version of every changed relative path, and moving the five files unique to v1.5.0 into a provenance-only archive. No archived file is used by current scripts, indices, or claims.
