# Results and claim boundaries

## Primary ZTF findings

The validated 2642-object ZTF layer gives a high-minus-low host-mass step of
-0.0751448 +/- 0.0084868 mag and a continuous mass slope of
-0.0449620 +/- 0.0048974 mag dex^-1. These establish a secure host residual
within the processed ZTF product.

Across five equal-number redshift bins, the fitted step becomes less negative.
The nominal coefficient slope is +1.502655 +/- 0.284420 mag per unit redshift
(p = 0.013226). A conservative unit-scale floor leaves the estimate unchanged,
widens its uncertainty to 0.485394, and gives p = 0.053473. The individual-level
H-by-z coefficient is unresolved. The supported statement is therefore that the
binned sequence challenges an unqualified scalar description; the release does
not establish a unique smooth evolution law.

The clearest additional structure is environmental. The mass-offset interaction
is +0.234155 +/- 0.045546 mag per unit log10(1+d_DLR), with bootstrap 95 per cent
interval [0.129919, 0.333471] and Freedman-Lane permutation p = 0.00019996. The
mass step changes from -0.098309 +/- 0.010297 mag at d_DLR < 1 to
-0.030122 +/- 0.014713 mag at d_DLR >= 1. The interaction remains positive in
all five redshift bins.

## Validated selection-forward and influence results

The selection-forward audit is aligned to the canonical validated response,
fixed redshift edges, 250 km s^-1 uncertainty convention, and residual-scale WLS
covariance. The observed Q is reached or exceeded in
10/300 zero-effect and
8/300 constant-step
realisations. The validated tomographic positive control reaches or exceeds the
observed Q in 239/300
realisations. In the 3000-draw global zero-host audit, no draw is as negative as
the observed step; the leading-one resolution is 0.000333222.

These are stress and recoverability diagnostics under the measured empirical
selection surface, not cadence-level survey simulations. Every single-object
deletion preserves the positive sign of the five-bin slope, although the Q
threshold is less stable. Selection and influence evidence is therefore
interpreted jointly rather than as a standalone exclusion test.

## External products

Pantheon+ and DES-SN5YR do not show significant five-bin tomography in their
final processed products. Their observed covariate distributions are strongly
separable from ZTF, especially for DES-SN5YR. These are product-level context
and support diagnostics, not direct replications of the ZTF selection and
local-environment protocol.

All exact values and source tables are listed in `metadata/key_results.csv`.
