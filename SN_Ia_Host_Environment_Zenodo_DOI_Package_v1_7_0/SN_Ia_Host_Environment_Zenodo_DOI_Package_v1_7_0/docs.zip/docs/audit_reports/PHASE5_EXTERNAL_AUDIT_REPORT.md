# Phase 5: reduced external-product robustness and common-support audit

## Why a reduced rather than full external protocol?

Pantheon+ and DES-SN5YR contain final object-level products from which global
and redshift-binned host coefficients can be estimated. They do not provide
the parent catalogue plus raw-to-final inclusion labels needed to reconstruct
a ZTF-equivalent selection surface. The full selection-forward protocol is
therefore not identifiable from these final products. The influence, binning,
bootstrap, and common-support components are identifiable and were performed.

## Pantheon+ product-level result

- Global step: -0.04426226 +/- 0.01278146 mag.
- Five-bin slope: +0.55197861 +/- 1.33734289; p = 0.707520.
- Leave-one-out slope range: [+0.24536166, +0.79155142].
- Fixed-edge bootstrap 95% interval: [-1.41808972, +2.23705226].
- Interpretation: single-object deletion preserves the positive sign, but the
  sampling interval crosses zero and the 3--6-bin grid includes a fixed-width
  sign reversal. No external tomography detection is established.

## DES-SN5YR corrected-HD result

- Global step: +0.00054574 +/- 0.00822526 mag.
- Five-bin slope: -0.04047465 +/- 0.04011701; p = 0.387332.
- Leave-one-out slope range: [-0.04621129, -0.03402038].
- Fixed-edge bootstrap 95% interval: [-0.11345995, +0.03429733].
- Only 197 of 1829 objects occupy the ZTF redshift support. The
  support-restricted slope is +0.59795075 +/- 1.37818717 (p = 0.693692).
- Interpretation: the full-product negative slope is not significant and
  changes sign under ZTF-range restriction. It is support-dependent context,
  not a direct replication statistic.

## Common support

- ZTF vs Pantheon+ classifier AUC: 0.851164 +/- 0.019938.
- ZTF vs DES-SN5YR classifier AUC: 0.994998 +/- 0.001315.
- ZTF vs Pantheon+ redshift SMD / KS D: -1.378314 / 0.562199.
- ZTF vs Pantheon+ log-error SMD / KS D: +1.143825 / 0.519033.
- ZTF vs DES redshift SMD / KS D: +2.719989 / 0.892291.
- ZTF vs DES host-mass SMD / KS D: +0.558655 / 0.222370.
- ZTF vs DES log-error SMD / KS D: +1.494567 / 0.899066.

## Manuscript-level conclusion

The criticism is now addressed empirically. The full external
selection-forward audit is unavailable for a specific design-data reason, not
because external robustness was ignored. Every estimable common-denominator
component has been applied, and the resulting support diagnostics quantify
why Pantheon+ and DES-SN5YR remain product-level context rather than direct
ZTF replications.
