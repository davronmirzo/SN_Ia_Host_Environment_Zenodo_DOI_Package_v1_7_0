# Validated fixed-edge selection-forward audit

## Observed target

- Five-bin tomography slope: +1.502655 mag per unit redshift
- Five-bin heterogeneity: Q = 10.613654
- Chi-square probability: p = 0.031267
- Degrees of freedom: 4
- Fixed bin edges and response convention: canonical 2642-object validated layer
- Peculiar-velocity convention: 250 km s^-1

## Forward-simulation results

| Input | Median slope | Median Q | 16--84% Q | Q >= observed | Leading-one exceedance |
|---|---:|---:|---:|---:|---:|
| Zero effect | +0.1058 | 3.1415 | [1.4063, 6.4974] | 10/300 | 0.0365 |
| Constant official step | +0.0610 | 3.2956 | [1.5372, 6.4881] | 8/300 | 0.0299 |
| Validated observed tomography | +1.5968 | 15.4187 | [9.4297, 23.8250] | 239/300 | 0.7973 |

## Global zero-host audit

- Draws: 3000
- Median recovered global step: -0.002377 mag
- 95 per cent interval: [-0.019069, +0.014373] mag
- Draws as negative as the observed -0.075145 mag step: 0/3000
- Leading-one probability: 0.000333222

## Interpretation

The observed Q remains uncommon under the aligned zero-effect and constant-step
forward inputs. The current validated tomographic positive control reproduces
or exceeds the observed Q in approximately 80 per cent of simulations. These
quantities are selection-surface stress diagnostics, not end-to-end survey
exclusion probabilities. The tomographic positive-control exceedance is a
recovery fraction rather than a null-hypothesis p-value.
