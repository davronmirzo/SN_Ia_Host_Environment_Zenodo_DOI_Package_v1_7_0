# Phase-4 environment stratification and interaction-stability audit

## Main continuous interaction

- Simple mass--offset interaction:
  +0.234155 +/- 0.045546,
  Wald p = 2.93251e-07.
- Object bootstrap 95% interval:
  [+0.129919,
   +0.333471].
- Bootstrap positive fraction:
  1.0000.
- Weighted Freedman--Lane permutation p:
  0.00019996.

The interaction remains strong in the full environmental model:
+0.256691 +/- 0.046863.
Availability-IPW gives:
+0.252669 +/- 0.044725.

## Environment-stratified mass steps

- Inner host (d_DLR < 1):
  -0.098309
  +/- 0.010297 mag.
- Outer host (d_DLR >= 1):
  -0.030122
  +/- 0.014713 mag.
- Inner-minus-outer contrast:
  -0.068187 mag;
  bootstrap 95% interval
  [-0.104459,
   -0.031233].

The local-colour split is weaker:
-0.033131 mag;
bootstrap 95% interval
[-0.069353,
 +0.003798].

## Interaction stability across redshift

The mass--offset interaction is positive in all five equal-number redshift
bins. Its between-bin heterogeneity is Q =
2.6710, p =
0.6143. A weighted linear trend of the
interaction with redshift gives
-0.1937 +/-
2.4856, p =
0.9428.

Thus there is no evidence that the mass--offset coupling is confined to the
lowest-redshift bin or evolves systematically across the analysed redshift
range. Individual-bin significance varies, so the correct statement is sign
consistency and lack of detected heterogeneity, not five independent
detections.

## Local-colour interaction

- Simple interaction:
  +0.006991 +/- 0.021071,
  p = 0.7401.
- Full-model interaction:
  +0.014518 +/- 0.021224,
  p = 0.4940.
- Availability-IPW interaction:
  +0.011516 +/- 0.020858,
  p = 0.5809.
- Permutation p:
  0.7477.

Local colour is therefore useful as an additive proxy in the wider model but
does not show a stable mass--local-colour interaction in this audit.
