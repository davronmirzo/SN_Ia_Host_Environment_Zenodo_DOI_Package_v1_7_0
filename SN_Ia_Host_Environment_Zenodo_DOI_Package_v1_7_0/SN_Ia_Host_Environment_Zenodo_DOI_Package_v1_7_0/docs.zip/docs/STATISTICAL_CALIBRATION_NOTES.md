# Statistical calibration and methods-completeness notes

Version 1.5.0 adds the following machine-readable and documented elements:

- nominal and conservative unit-scale-floor calibration of the five-bin
  coefficient meta-slope;
- the hierarchical extra-scatter likelihood output
  (`protocol_hierarchical_nonstationarity.csv`);
- the complete seven-model reconciliation ladder
  (`reconciliation60_best_model_ladder.csv`);
- overdispersion-aware nested comparisons;
- exact resampling and simulation counts;
- the Phase-5 external-product bootstrap, leave-one-out, binning,
  redshift-support, SMD, KS, and separability audits.

The nominal five-bin slope is +1.502655 with standard error 0.284420 and
t-distribution probability 0.013226. The second-stage residual variance scale
is 0.343344. Applying a unit scale floor leaves the slope unchanged, widens
the standard error to 0.485394, and gives probability 0.053473. The release
therefore preserves the nominal predefined summary while exposing its
calibration sensitivity.

The hierarchical extra-scatter estimates are approximately 0.021--0.034 mag,
with likelihood-ratio probabilities that vary by partition. They are
supporting model-adequacy diagnostics and do not provide stronger or more
configuration-stable evidence than the predefined binned analyses.
