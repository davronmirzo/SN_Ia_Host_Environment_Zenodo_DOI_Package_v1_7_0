# Figure 4 caption and alt text

## Caption

Validated selection-forward recovery on the current fixed five-bin analysis
convention. Left: median recovered coefficient-versus-redshift slopes for
zero-effect, constant-step, and validated-tomographic inputs; horizontal error
bars show the 16th--84th percentile ranges and the dashed vertical line marks
the observed validated ZTF slope. Right: distributions of the five-bin
heterogeneity statistic under the same three inputs; the dashed horizontal line
marks the observed value, Q = 10.61. Zero-effect and constant-step inputs rarely
reach the observed heterogeneity, whereas the validated-tomographic positive
control does so frequently.

## Alt text

Two-panel selection-forward diagnostic. The left panel shows recovered slopes
near zero for zero-effect and constant-step simulations and a positive recovered
slope near the observed value for the validated-tomographic input. The right
panel shows low heterogeneity for zero and constant inputs and much higher
heterogeneity for the validated-tomographic input, with many simulations above
the observed threshold. Axis labels and tick labels are enlarged and bold for
legibility.
