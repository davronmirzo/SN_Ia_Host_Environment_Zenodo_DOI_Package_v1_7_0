#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
make_population_drift_figure.py

Creates:
    figures/fig_population_drift_vs_redshift.pdf

Run from the project root:
    python make_population_drift_figure.py
"""

from pathlib import Path
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / "results" / "tables"
FIGS = ROOT / "figures"
FIGS.mkdir(parents=True, exist_ok=True)

path = TABLES / "redshift_tomography_population_drift.csv"
if not path.exists():
    raise SystemExit(
        f"Missing table: {path}\n"
        "The frozen input is expected at "
        "results/tables/redshift_tomography_population_drift.csv."
    )

df = pd.read_csv(path)
if df.empty:
    raise SystemExit(f"Empty table: {path}")

required = ["z_median", "high_mass_fraction", "median_x1", "median_c", "median_local_color", "median_mb_err"]
missing = [c for c in required if c not in df.columns]
if missing:
    raise SystemExit(f"Missing columns in {path.name}: {missing}\nExisting columns: {list(df.columns)}")

z = pd.to_numeric(df["z_median"], errors="coerce")

fig, ax1 = plt.subplots(figsize=(8.4, 5.3))

# Directly comparable dimensionless quantities on left axis.
ax1.plot(z, pd.to_numeric(df["high_mass_fraction"], errors="coerce"),
         marker="o", label=r"High-mass fraction")
ax1.plot(z, pd.to_numeric(df["median_c"], errors="coerce"),
         marker="s", label=r"Median colour $c$")
ax1.plot(z, pd.to_numeric(df["median_local_color"], errors="coerce"),
         marker="D", label="Median local colour")
ax1.set_xlabel("Median redshift in bin")
ax1.set_ylabel("Fraction / colour statistic")
ax1.grid(alpha=0.25)

# x1 has a larger numerical scale; put it on the right axis.
ax2 = ax1.twinx()
ax2.plot(z, pd.to_numeric(df["median_x1"], errors="coerce"),
         marker="^", linestyle="--", label=r"Median $x_1$")
ax2.set_ylabel(r"Median $x_1$")

# mb_err is small; annotate as text rather than putting on a third axis.
for _, row in df.iterrows():
    zz = pd.to_numeric(row["z_median"], errors="coerce")
    mbe = pd.to_numeric(row["median_mb_err"], errors="coerce")
    if np.isfinite(zz) and np.isfinite(mbe):
        ax1.text(zz, ax1.get_ylim()[0], f"{mbe:.3f}", ha="center", va="bottom", fontsize=7, rotation=90)

ax1.text(0.01, 0.02, r"Bottom labels: median $\sigma(m_B^\ast)$",
         transform=ax1.transAxes, fontsize=8, va="bottom")

# Combined legend.
lines1, labels1 = ax1.get_legend_handles_labels()
lines2, labels2 = ax2.get_legend_handles_labels()
ax1.legend(lines1 + lines2, labels1 + labels2, frameon=False, loc="best")

ax1.set_title("Population drift across ZTF redshift bins")
fig.tight_layout()

out = FIGS / "fig_population_drift_vs_redshift.pdf"
fig.savefig(out, bbox_inches="tight")
print("[OK]", out)

plt.close(fig)
print("\nDone.")
