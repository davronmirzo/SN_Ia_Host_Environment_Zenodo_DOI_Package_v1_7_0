#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Validated-layer forward-selection rerun for the ZTF host residual.

This audit removes the legacy harmonized tomography reference from the
selection-forward branch. It uses:

* the canonical 2642-object validated residual layer to define the response
  model, empirical residual distribution, fixed five-bin edges, observed
  bin-local host steps, and observed Q/slope;
* the 3483-object raw-to-final selection-training layer to define the parent
  covariate surface;
* the frozen empirical ridge-logistic selection model, with one intercept-only
  calibration over regression-eligible parent rows so that the expected
  selected denominator equals 2642 while preserving all fitted odds ratios and
  probability ranking;
* residual uncertainties recomputed exactly as

      sqrt(m_B_err^2 + [(5/ln10) * (250 km/s)/(c z)]^2),

  matching the current v_pec=250 km/s convention;
* fixed observed five-bin redshift edges and the same residual-scale WLS
  covariance used by the primary analysis.

Outputs replace the older forward-selection tables and add an explicit run
configuration, probability audit, 3000-draw global null, 150-draw offset
positive control, manuscript Table 6, and Figure 4.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.optimize import brentq
from scipy.special import expit
from scipy.stats import chi2, t as student_t

C_KMS = 299792.458
VPEC_KMS = 250.0
N_GLOBAL_NULL = 3000
N_FORWARD = 300
N_OFFSET = 150
SEED = 20260722
TARGET_SELECTED_N = 2642


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True, help="Extracted package root.")
    return parser.parse_args()


def wls_fit(y: np.ndarray, err: np.ndarray, columns: list[np.ndarray]) -> dict[str, object]:
    X = np.column_stack([np.ones(len(y)), *columns])
    weight = 1.0 / np.maximum(err, 1.0e-8) ** 2
    normal = X.T @ (weight[:, None] * X)
    inverse = np.linalg.pinv(normal)
    beta = inverse @ (X.T @ (weight * y))
    residual = y - X @ beta
    dof = len(y) - X.shape[1]
    if dof <= 0:
        raise ValueError("Non-positive WLS degrees of freedom.")
    mse = float(np.sum(weight * residual**2) / dof)
    covariance = inverse * mse
    se = np.sqrt(np.maximum(np.diag(covariance), 0.0))
    return {
        "beta": beta,
        "se": se,
        "residual": residual,
        "mse": mse,
        "dof": dof,
        "n": len(y),
    }


def fit_mass_step(frame: pd.DataFrame) -> dict[str, float]:
    fit = wls_fit(
        frame["synthetic_residual"].to_numpy(float),
        frame["residual_err_250"].to_numpy(float),
        [
            frame["x1"].to_numpy(float),
            frame["c"].to_numpy(float),
            frame["H"].to_numpy(float),
        ],
    )
    coefficient = float(fit["beta"][3])
    standard_error = float(fit["se"][3])
    probability = float(
        2.0 * student_t.sf(abs(coefficient / standard_error), int(fit["dof"]))
    )
    return {
        "mass_step": coefficient,
        "mass_step_err": standard_error,
        "p_value": probability,
        "chi2_red": float(fit["mse"]),
        "rms": float(np.sqrt(np.mean(np.asarray(fit["residual"]) ** 2))),
        "nmad": float(
            1.4826
            * np.median(
                np.abs(
                    np.asarray(fit["residual"])
                    - np.median(np.asarray(fit["residual"]))
                )
            )
        ),
    }


def fit_offset_interaction(frame: pd.DataFrame) -> dict[str, float]:
    r = frame["log1p_host_dlr"].to_numpy(float)
    r_centered = r - float(np.mean(r))
    h = frame["H"].to_numpy(float)
    fit = wls_fit(
        frame["synthetic_residual"].to_numpy(float),
        frame["residual_err_250"].to_numpy(float),
        [
            frame["x1"].to_numpy(float),
            frame["c"].to_numpy(float),
            h,
            r_centered,
            h * r_centered,
        ],
    )
    coefficient = float(fit["beta"][5])
    standard_error = float(fit["se"][5])
    probability = float(
        2.0 * student_t.sf(abs(coefficient / standard_error), int(fit["dof"]))
    )
    return {
        "offset_interaction": coefficient,
        "offset_interaction_err": standard_error,
        "offset_interaction_p": probability,
    }


def summarize_tomography(bin_rows: list[dict[str, float]]) -> dict[str, float]:
    table = pd.DataFrame(bin_rows).sort_values("bin_id")
    steps = table["mass_step"].to_numpy(float)
    errors = table["mass_step_err"].to_numpy(float)
    medians = table["z_median"].to_numpy(float)
    weight = 1.0 / errors**2
    ivw_mean = float(np.sum(weight * steps) / np.sum(weight))
    q_value = float(np.sum(weight * (steps - ivw_mean) ** 2))
    q_probability = float(chi2.sf(q_value, len(steps) - 1))

    design = np.column_stack([np.ones(len(medians)), medians - np.mean(medians)])
    sqrt_weight = np.sqrt(weight)
    weighted_design = design * sqrt_weight[:, None]
    beta, *_ = np.linalg.lstsq(weighted_design, steps * sqrt_weight, rcond=None)
    residual = steps - design @ beta
    dof = len(steps) - 2
    weighted_sse = float(np.sum(weight * residual**2))
    covariance = (
        np.linalg.pinv(weighted_design.T @ weighted_design)
        * (weighted_sse / dof)
    )
    slope = float(beta[1])
    slope_error = float(np.sqrt(covariance[1, 1]))
    slope_probability = float(
        2.0 * student_t.sf(abs(slope / slope_error), dof)
    )
    return {
        "inverse_variance_mean_step": ivw_mean,
        "heterogeneity_Q": q_value,
        "heterogeneity_p_chi2": q_probability,
        "tomography_slope": slope,
        "tomography_slope_err": slope_error,
        "tomography_slope_p_t": slope_probability,
    }


def selection_probabilities(frame: pd.DataFrame, coefficients: pd.DataFrame) -> np.ndarray:
    intercept = float(
        coefficients.loc[coefficients["term"] == "intercept", "coefficient"].iloc[0]
    )
    eta = np.full(len(frame), intercept, dtype=float)
    for row in coefficients.itertuples(index=False):
        term = str(row.term)
        if term == "intercept":
            continue
        coefficient = float(row.coefficient)
        if term.endswith("_missing"):
            base = term[: -len("_missing")]
            eta += coefficient * frame[base].isna().to_numpy(float)
        else:
            median = float(row.feature_median)
            scale = float(row.feature_scale)
            values = frame[term].astype(float).fillna(median).to_numpy()
            eta += coefficient * ((values - median) / scale)
    return expit(eta)


def percentile_summary(values: np.ndarray) -> dict[str, float]:
    return {
        "median": float(np.median(values)),
        "p16": float(np.percentile(values, 16)),
        "p84": float(np.percentile(values, 84)),
        "p2p5": float(np.percentile(values, 2.5)),
        "p97p5": float(np.percentile(values, 97.5)),
    }


def main() -> None:
    args = parse_args()
    root = Path(args.root).expanduser().resolve()
    table_dir = root / "results" / "tables"
    figure_dir = root / "figures"
    doc_dir = root / "docs"

    validated = pd.read_csv(root / "data" / "processed" / "ZTF_DR2_validated_residual_layer.csv")
    parent_raw = pd.read_csv(root / "data" / "processed" / "empirical_selection_training_sample.csv")
    coefficients = pd.read_csv(table_dir / "empirical_selection_model_coefficients.csv")
    observed_bins = pd.read_csv(table_dir / "phase3_tomography_baseline_bins.csv")
    observed_global = pd.read_csv(table_dir / "phase3_global_and_tomography_baseline.csv").iloc[0]
    environmental = pd.read_csv(table_dir / "phase4_global_interactions.csv")

    validated = validated.copy().reset_index(drop=True)
    validated["H"] = (validated["host_logmass"] >= 10.0).astype(float)

    # Recover the exact fixed edges used by the primary five-bin analysis.
    edges = np.quantile(validated["z"].to_numpy(float), np.linspace(0.0, 1.0, 6))
    edges[0] -= 1.0e-10
    edges[-1] += 1.0e-10
    validated["zbin"] = pd.cut(
        validated["z"], bins=edges, labels=False, include_lowest=True
    ).astype(int)

    # Internal integrity checks against frozen primary results.
    observed_check = fit_mass_step(
        validated.rename(
            columns={
                "residual": "synthetic_residual",
                "residual_err": "residual_err_250",
            }
        )
    )
    if not np.isclose(observed_check["mass_step"], float(observed_global["mass_step"]), atol=5e-10):
        raise RuntimeError("Validated global mass-step integrity check failed.")

    reconstructed_bins: list[dict[str, float]] = []
    for bin_id in range(5):
        group = validated.loc[validated["zbin"] == bin_id].rename(
            columns={
                "residual": "synthetic_residual",
                "residual_err": "residual_err_250",
            }
        )
        fit = fit_mass_step(group)
        reconstructed_bins.append(
            {
                "bin_id": bin_id + 1,
                "z_median": float(group["z"].median()),
                "n_bin": int(len(group)),
                **fit,
            }
        )
    observed_summary_check = summarize_tomography(reconstructed_bins)
    if not np.isclose(
        observed_summary_check["tomography_slope"],
        float(observed_global["tomography_slope"]),
        atol=5e-10,
    ):
        raise RuntimeError("Validated tomography-slope integrity check failed.")
    if not np.isclose(
        observed_summary_check["heterogeneity_Q"],
        float(observed_global["heterogeneity_Q"]),
        atol=5e-10,
    ):
        raise RuntimeError("Validated heterogeneity-Q integrity check failed.")

    # Parent rows eligible for the same regression variables and fixed z support.
    eligible = parent_raw[["z", "x1", "c", "host_logmass", "mb_err", "log1p_host_dlr"]].notna().all(axis=1)
    eligible &= parent_raw["z"].between(edges[0], edges[-1], inclusive="both")
    parent = parent_raw.loc[eligible].copy().reset_index(drop=True)
    parent["H"] = (parent["host_logmass"] >= 10.0).astype(float)
    parent["zbin"] = pd.cut(
        parent["z"], bins=edges, labels=False, include_lowest=True
    ).astype(int)
    parent["residual_err_250"] = np.sqrt(
        parent["mb_err"].to_numpy(float) ** 2
        + (
            (5.0 / np.log(10.0))
            * (VPEC_KMS / C_KMS)
            / parent["z"].to_numpy(float)
        )
        ** 2
    )

    p_original = selection_probabilities(parent, coefficients)
    original_logit = np.log(p_original / (1.0 - p_original))
    intercept_shift = brentq(
        lambda shift: float(np.sum(expit(original_logit + shift)) - TARGET_SELECTED_N),
        -20.0,
        20.0,
    )
    p_calibrated = expit(original_logit + intercept_shift)
    parent["selection_probability_original"] = p_original
    parent["selection_probability_validated_calibrated"] = p_calibrated

    probability_audit = pd.DataFrame(
        [
            {
                "raw_rows": int(len(parent_raw)),
                "regression_eligible_parent_rows": int(len(parent)),
                "target_expected_selected_n": TARGET_SELECTED_N,
                "original_expected_selected_n_on_eligible_parent": float(np.sum(p_original)),
                "calibrated_expected_selected_n": float(np.sum(p_calibrated)),
                "original_mean_probability": float(np.mean(p_original)),
                "calibrated_mean_probability": float(np.mean(p_calibrated)),
                "logit_intercept_shift": float(intercept_shift),
                "probability_rank_correlation": float(
                    pd.Series(p_original).corr(pd.Series(p_calibrated), method="spearman")
                ),
                "vpec_km_s": VPEC_KMS,
                "z_min_fixed": float(edges[0]),
                "z_max_fixed": float(edges[-1]),
            }
        ]
    )
    probability_audit.to_csv(
        table_dir / "validated_forward_selection_probability_audit.csv", index=False
    )

    # Reduced response model: preserve measured z, x1 and c dependence but no host term.
    z_center = float(validated["z"].median())
    reduced_fit = wls_fit(
        validated["residual"].to_numpy(float),
        validated["residual_err"].to_numpy(float),
        [
            validated["x1"].to_numpy(float),
            validated["c"].to_numpy(float),
            (validated["z"].to_numpy(float) - z_center),
        ],
    )
    parent["reduced_mean"] = (
        float(reduced_fit["beta"][0])
        + float(reduced_fit["beta"][1]) * parent["x1"].to_numpy(float)
        + float(reduced_fit["beta"][2]) * parent["c"].to_numpy(float)
        + float(reduced_fit["beta"][3]) * (parent["z"].to_numpy(float) - z_center)
    )

    validated["standardized_reduced_residual"] = (
        np.asarray(reduced_fit["residual"], dtype=float)
        / validated["residual_err"].to_numpy(float)
    )
    residual_pools = {
        bin_id: validated.loc[
            validated["zbin"] == bin_id, "standardized_reduced_residual"
        ].to_numpy(float)
        for bin_id in range(5)
    }

    observed_steps = observed_bins.sort_values("bin")["mass_step"].to_numpy(float)
    observed_slope = float(observed_global["tomography_slope"])
    observed_q = float(observed_global["heterogeneity_Q"])
    official_step = float(observed_global["mass_step"])

    offset_rows = environmental.loc[
        (environmental["model"].astype(str) == "offset_interaction_simple")
        & (environmental["term"].astype(str) == "H_R")
    ]
    if len(offset_rows) != 1:
        raise RuntimeError("Could not identify the frozen H_R offset interaction.")
    observed_offset_interaction = float(offset_rows.iloc[0]["coefficient"])
    validated_r_center = float(validated["log1p_host_dlr"].mean())

    rng = np.random.default_rng(SEED)

    def simulate_one(scenario: str, sim_id: int) -> tuple[dict[str, float], list[dict[str, float]]]:
        selected_mask = rng.random(len(parent)) < parent[
            "selection_probability_validated_calibrated"
        ].to_numpy(float)
        selected = parent.loc[selected_mask].copy().reset_index(drop=True)
        if len(selected) < 100:
            raise RuntimeError("Selection draw produced an implausibly small sample.")

        standardized_noise = np.empty(len(selected), dtype=float)
        selected_bins = selected["zbin"].to_numpy(int)
        for bin_id in range(5):
            indices = np.flatnonzero(selected_bins == bin_id)
            standardized_noise[indices] = rng.choice(
                residual_pools[bin_id], size=len(indices), replace=True
            )

        h = selected["H"].to_numpy(float)
        if scenario in {"zero_mass_effect", "global_zero_host_null"}:
            host_component = np.zeros(len(selected), dtype=float)
        elif scenario == "constant_official_mass_step":
            host_component = official_step * h
        elif scenario == "observed_validated_tomographic_mass_step":
            host_component = observed_steps[selected_bins] * h
        elif scenario == "observed_validated_offset_interaction":
            host_component = (
                official_step * h
                + observed_offset_interaction
                * h
                * (selected["log1p_host_dlr"].to_numpy(float) - validated_r_center)
            )
        else:
            raise ValueError(f"Unknown scenario: {scenario}")

        selected["synthetic_residual"] = (
            selected["reduced_mean"].to_numpy(float)
            + host_component
            + selected["residual_err_250"].to_numpy(float) * standardized_noise
        )

        global_fit = fit_mass_step(selected)
        bin_rows: list[dict[str, float]] = []
        for bin_id in range(5):
            group = selected.loc[selected["zbin"] == bin_id]
            if len(group) < 20 or group["H"].nunique() < 2:
                raise RuntimeError("A simulation bin lacks sufficient class support.")
            fit = fit_mass_step(group)
            bin_rows.append(
                {
                    "scenario": scenario,
                    "sim_id": sim_id,
                    "bin_id": bin_id + 1,
                    "z_min_fixed": float(edges[bin_id]),
                    "z_max_fixed": float(edges[bin_id + 1]),
                    "z_median": float(group["z"].median()),
                    "n_bin": int(len(group)),
                    "high_mass_fraction": float(group["H"].mean()),
                    **fit,
                }
            )
        tomography = summarize_tomography(bin_rows)
        result = {
            "scenario": scenario,
            "sim_id": sim_id,
            "selected_n": int(len(selected)),
            "selected_fraction_of_eligible_parent": float(len(selected) / len(parent)),
            "mean_selection_probability_parent": float(
                parent["selection_probability_validated_calibrated"].mean()
            ),
            "high_mass_fraction_selected": float(selected["H"].mean()),
            **global_fit,
            **tomography,
        }
        if scenario == "observed_validated_offset_interaction":
            result.update(fit_offset_interaction(selected))
        return result, bin_rows

    # 3000-draw global null: global fit only, but generated by the exact same engine.
    global_null_rows: list[dict[str, float]] = []
    for sim_id in range(N_GLOBAL_NULL):
        result, _ = simulate_one("global_zero_host_null", sim_id)
        global_null_rows.append(result)
    global_null = pd.DataFrame(global_null_rows)
    global_null.to_csv(
        table_dir / "validated_forward_selection_global_null_draws.csv", index=False
    )

    # Three 300-draw scenarios used by Figure 4 and the Q audit.
    forward_rows: list[dict[str, float]] = []
    tomography_rows: list[dict[str, float]] = []
    scenario_order = [
        "zero_mass_effect",
        "constant_official_mass_step",
        "observed_validated_tomographic_mass_step",
    ]
    for scenario in scenario_order:
        for sim_id in range(N_FORWARD):
            result, bin_rows = simulate_one(scenario, sim_id)
            forward_rows.append(result)
            tomography_rows.extend(bin_rows)
    forward = pd.DataFrame(forward_rows)
    tomography = pd.DataFrame(tomography_rows)

    # Offset positive control uses the current observed interaction amplitude.
    offset_rows_out: list[dict[str, float]] = []
    for sim_id in range(N_OFFSET):
        result, _ = simulate_one("observed_validated_offset_interaction", sim_id)
        offset_rows_out.append(result)
    offset_draws = pd.DataFrame(offset_rows_out)

    # Compatibility outputs replace the legacy harmonized tables.
    forward_compat = forward.rename(
        columns={
            "tomography_slope_err": "tomography_slope_err",
            "tomography_slope_p_t": "p_value_tomography",
        }
    ).copy()
    forward_compat["observed_official_mass_step"] = official_step
    forward_compat["observed_tomography_slope"] = observed_slope
    forward_compat["observed_heterogeneity_Q"] = observed_q
    forward_compat["selection_probability_calibration"] = "eligible-parent intercept shift to N=2642"
    forward_compat.to_csv(table_dir / "forward_selection_simulation_draws.csv", index=False)
    tomography.to_csv(table_dir / "forward_selection_tomography_recovery.csv", index=False)
    offset_draws.to_csv(table_dir / "validated_forward_selection_offset_positive_control_draws.csv", index=False)

    summary_rows: list[dict[str, float | str | int]] = []
    q_rows: list[dict[str, float | str | int]] = []
    for scenario, group in forward.groupby("scenario", sort=False):
        mass = group["mass_step"].to_numpy(float)
        slope = group["tomography_slope"].to_numpy(float)
        q_values = group["heterogeneity_Q"].to_numpy(float)
        ms = percentile_summary(mass)
        ss = percentile_summary(slope)
        qs = percentile_summary(q_values)
        n_q = int(np.sum(q_values >= observed_q))
        summary_rows.append(
            {
                "scenario": scenario,
                "n_sim_ok": int(len(group)),
                "median_mass_step": ms["median"],
                "p16_mass_step": ms["p16"],
                "p84_mass_step": ms["p84"],
                "p2p5_mass_step": ms["p2p5"],
                "p97p5_mass_step": ms["p97p5"],
                "observed_official_mass_step": official_step,
                "fraction_mass_step_le_observed": float(np.mean(mass <= official_step)),
                "median_tomography_slope": ss["median"],
                "p16_tomography_slope": ss["p16"],
                "p84_tomography_slope": ss["p84"],
                "p2p5_tomography_slope": ss["p2p5"],
                "p97p5_tomography_slope": ss["p97p5"],
                "observed_tomography_slope": observed_slope,
                "fraction_tomography_slope_ge_observed": float(np.mean(slope >= observed_slope)),
                "median_heterogeneity_Q": qs["median"],
                "n_Q_ge_observed": n_q,
                "fraction_Q_ge_observed": float(n_q / len(group)),
                "empirical_Q_exceedance_leading_one": float((n_q + 1) / (len(group) + 1)),
                "median_selected_n": float(np.median(group["selected_n"])),
                "median_selected_fraction": float(np.median(group["selected_fraction_of_eligible_parent"])),
                "label_method": "validated_layer_fixed_edges_vpec250",
            }
        )
        q_rows.append(
            {
                "scenario": scenario,
                "n_sim_ok": int(len(group)),
                "observed_Q": observed_q,
                "observed_Q_chi2_p": float(observed_global["heterogeneity_p"]),
                "median_Q": qs["median"],
                "p16_Q": qs["p16"],
                "p84_Q": qs["p84"],
                "p2p5_Q": qs["p2p5"],
                "p97p5_Q": qs["p97p5"],
                "n_Q_ge_observed": n_q,
                "fraction_Q_ge_observed": float(n_q / len(group)),
                "empirical_p_leading_one": float((n_q + 1) / (len(group) + 1)),
                "fraction_nominal_p_lt_0p05": float(
                    np.mean(group["heterogeneity_p_chi2"].to_numpy(float) < 0.05)
                ),
            }
        )
    forward_summary = pd.DataFrame(summary_rows)
    q_summary = pd.DataFrame(q_rows)
    forward_summary.to_csv(table_dir / "forward_selection_simulation_summary.csv", index=False)
    q_summary.to_csv(table_dir / "selection_stress_heterogeneity_Q_summary.csv", index=False)

    q_draws = forward[
        [
            "scenario",
            "sim_id",
            "selected_n",
            "inverse_variance_mean_step",
            "heterogeneity_Q",
            "heterogeneity_p_chi2",
        ]
    ].copy()
    q_draws["heterogeneity_dof"] = 4
    q_draws["Q_ge_observed"] = (q_draws["heterogeneity_Q"] >= observed_q).astype(int)
    q_draws["nominal_heterogeneity_p_lt_0p05"] = (
        q_draws["heterogeneity_p_chi2"] < 0.05
    ).astype(int)
    q_draws.to_csv(table_dir / "selection_stress_heterogeneity_Q_draws.csv", index=False)
    pd.DataFrame(
        [
            {
                "source": "validated_ZTF_fixed_edge_five_bin_analysis",
                "n_bins": 5,
                "heterogeneity_Q": observed_q,
                "heterogeneity_dof": 4,
                "heterogeneity_p_chi2": float(observed_global["heterogeneity_p"]),
                "tomography_slope": observed_slope,
                "tomography_slope_se": float(observed_global["tomography_slope_se"]),
            }
        ]
    ).to_csv(table_dir / "selection_stress_heterogeneity_Q_observed.csv", index=False)

    global_values = global_null["mass_step"].to_numpy(float)
    global_extreme = int(np.sum(global_values <= official_step))
    global_null_summary = pd.DataFrame(
        [
            {
                "scenario": "global_zero_host_null",
                "n_sim_ok": int(len(global_null)),
                "median_mass_step": float(np.median(global_values)),
                "p16_mass_step": float(np.percentile(global_values, 16)),
                "p84_mass_step": float(np.percentile(global_values, 84)),
                "p2p5_mass_step": float(np.percentile(global_values, 2.5)),
                "p97p5_mass_step": float(np.percentile(global_values, 97.5)),
                "observed_mass_step": official_step,
                "n_mass_step_le_observed": global_extreme,
                "fraction_mass_step_le_observed": float(global_extreme / len(global_null)),
                "empirical_p_leading_one": float((global_extreme + 1) / (len(global_null) + 1)),
                "median_selected_n": float(np.median(global_null["selected_n"])),
            }
        ]
    )
    global_null_summary.to_csv(
        table_dir / "validated_forward_selection_global_null_summary.csv", index=False
    )

    offset_values = offset_draws["offset_interaction"].to_numpy(float)
    offset_summary_values = percentile_summary(offset_values)
    offset_summary = pd.DataFrame(
        [
            {
                "scenario": "observed_validated_offset_interaction",
                "n_sim_ok": int(len(offset_draws)),
                "inserted_global_mass_step": official_step,
                "inserted_offset_interaction": observed_offset_interaction,
                "median_recovered_global_mass_step": float(np.median(offset_draws["mass_step"])),
                "median_recovered_offset_interaction": offset_summary_values["median"],
                "p16_recovered_offset_interaction": offset_summary_values["p16"],
                "p84_recovered_offset_interaction": offset_summary_values["p84"],
                "p2p5_recovered_offset_interaction": offset_summary_values["p2p5"],
                "p97p5_recovered_offset_interaction": offset_summary_values["p97p5"],
                "fraction_recovered_positive": float(np.mean(offset_values > 0.0)),
                "fraction_recovered_ge_inserted": float(np.mean(offset_values >= observed_offset_interaction)),
                "median_selected_n": float(np.median(offset_draws["selected_n"])),
            }
        ]
    )
    offset_summary.to_csv(
        table_dir / "validated_forward_selection_offset_positive_control_summary.csv", index=False
    )

    # Manuscript Table 6 replacement.
    scenario_map = {
        "zero_mass_effect": "Zero-effect forward input",
        "constant_official_mass_step": "Constant official step",
        "observed_validated_tomographic_mass_step": "Validated observed tomography",
    }
    table6_rows: list[dict[str, object]] = []
    g = global_null_summary.iloc[0]
    table6_rows.append(
        {
            "input_or_audit": "Zero-host selection null",
            "recovered_global_step": f"median {g['median_mass_step']:+.4f} mag",
            "recovered_redshift_or_offset_structure": "not targeted",
            "empirical_diagnostic": (
                f"{int(g['n_mass_step_le_observed'])}/{int(g['n_sim_ok'])} as negative as observed; "
                f"leading-one p={g['empirical_p_leading_one']:.4g}"
            ),
        }
    )
    for row in forward_summary.to_dict(orient="records"):
        qrow = q_summary.loc[q_summary["scenario"] == row["scenario"]].iloc[0]
        table6_rows.append(
            {
                "input_or_audit": scenario_map[row["scenario"]],
                "recovered_global_step": f"median {row['median_mass_step']:+.4f} mag",
                "recovered_redshift_or_offset_structure": (
                    f"slope median {row['median_tomography_slope']:+.4f} mag per unit redshift"
                ),
                "empirical_diagnostic": (
                    f"{int(qrow['n_Q_ge_observed'])}/{int(qrow['n_sim_ok'])} reach Q_obs; "
                    f"leading-one exceedance={qrow['empirical_p_leading_one']:.4f}"
                ),
            }
        )
    o = offset_summary.iloc[0]
    table6_rows.append(
        {
            "input_or_audit": "Validated offset-dependent injection",
            "recovered_global_step": f"median {o['median_recovered_global_mass_step']:+.4f} mag",
            "recovered_redshift_or_offset_structure": (
                f"H x log10(1+d_DLR) median {o['median_recovered_offset_interaction']:+.4f} "
                "mag per unit log10(1+d_DLR)"
            ),
            "empirical_diagnostic": (
                f"{o['fraction_recovered_positive']:.3f} of draws recover positive sign"
            ),
        }
    )
    pd.DataFrame(table6_rows).to_csv(
        table_dir / "table06_selection_forward_summary.csv", index=False
    )

    # Figure 4: fixed current reference and regenerated distributions.
    display_order = scenario_order
    display_labels = ["Zero effect", "Constant step", "Validated\ntomography"]
    y_positions = np.arange(len(display_order))[::-1]
    medians = []
    lower = []
    upper = []
    q_plot = []
    for scenario in display_order:
        group = forward.loc[forward["scenario"] == scenario]
        vals = group["tomography_slope"].to_numpy(float)
        med = float(np.median(vals))
        p16 = float(np.percentile(vals, 16))
        p84 = float(np.percentile(vals, 84))
        medians.append(med)
        lower.append(med - p16)
        upper.append(p84 - med)
        q_plot.append(group["heterogeneity_Q"].to_numpy(float))

    fig, axes = plt.subplots(1, 2, figsize=(12.6, 5.25))
    axes[0].errorbar(
        medians,
        y_positions,
        xerr=np.vstack([lower, upper]),
        fmt="o",
        capsize=5,
        markersize=7,
        linewidth=1.7,
    )
    axes[0].axvline(observed_slope, linestyle="--", linewidth=1.5)
    axes[0].axvline(0.0, linewidth=1.0)
    axes[0].set_yticks(y_positions, labels=display_labels)
    axes[0].set_xlabel(
        "Recovered slope (mag per unit redshift)",
        fontsize=15.5,
        fontweight="bold",
        labelpad=8,
    )
    axes[0].set_title("Validated fixed-edge recovery", fontsize=17, pad=10)

    axes[1].boxplot(
        q_plot,
        tick_labels=["Zero\neffect", "Constant\nstep", "Validated\ntomography"],
        showfliers=False,
        widths=0.34,
        medianprops={"linewidth": 1.6},
        boxprops={"linewidth": 1.4},
        whiskerprops={"linewidth": 1.4},
        capprops={"linewidth": 1.4},
    )
    axes[1].axhline(observed_q, linestyle="--", linewidth=1.5)
    axes[1].set_ylabel(
        "Heterogeneity statistic Q",
        fontsize=15.5,
        fontweight="bold",
        labelpad=9,
    )
    axes[1].set_xlabel(
        "Forward-simulation input",
        fontsize=15.5,
        fontweight="bold",
        labelpad=8,
    )
    axes[1].set_title("Selection-forward heterogeneity", fontsize=17, pad=10)
    for axis in axes:
        axis.tick_params(axis="both", which="major", labelsize=13.5, width=1.2, length=5)
        for label in axis.get_xticklabels() + axis.get_yticklabels():
            label.set_fontweight("bold")
    axes[0].set_xlim(-0.55, 2.28)
    axes[1].set_ylim(-1.5, 38.5)
    fig.subplots_adjust(left=0.145, right=0.985, bottom=0.205, top=0.875, wspace=0.23)
    fig.savefig(figure_dir / "fig04_selection_forward_validation.pdf", bbox_inches="tight", pad_inches=0.06)
    plt.close(fig)

    # Selection-null figure for Appendix B1.
    fig, ax = plt.subplots(figsize=(7.2, 4.5))
    ax.hist(global_values, bins=45)
    ax.axvline(official_step, linestyle=":", linewidth=1.4, label="Observed validated step")
    ax.axvline(float(np.median(global_values)), linestyle="--", linewidth=1.2, label="Null median")
    ax.set_xlabel("Recovered global host-mass step (mag)")
    ax.set_ylabel("Number of simulations")
    ax.set_title("Validated zero-host selection-null recovery")
    ax.legend()
    fig.tight_layout()
    fig.savefig(figure_dir / "figB1_validated_selection_null_recovery.pdf", bbox_inches="tight")
    plt.close(fig)

    run_config = {
        "script": "code/77_validated_forward_selection_rerun.py",
        "seed": SEED,
        "n_global_null": N_GLOBAL_NULL,
        "n_forward_per_scenario": N_FORWARD,
        "n_offset_positive_control": N_OFFSET,
        "validated_rows": int(len(validated)),
        "eligible_parent_rows": int(len(parent)),
        "target_expected_selected_n": TARGET_SELECTED_N,
        "selection_probability_intercept_shift": float(intercept_shift),
        "vpec_km_s": VPEC_KMS,
        "uncertainty_formula": "sqrt(mb_err^2 + ((5/ln10)*(vpec/c)/z)^2)",
        "fixed_redshift_edges": [float(value) for value in edges],
        "observed_global_mass_step": official_step,
        "observed_bin_mass_steps": [float(value) for value in observed_steps],
        "observed_tomography_slope": observed_slope,
        "observed_heterogeneity_Q": observed_q,
        "observed_offset_interaction": observed_offset_interaction,
        "noise_model": "within-fixed-bin bootstrap of standardized residuals from validated reduced y~x1+c+z model",
        "covariance": "WLS covariance multiplied by residual mean-square scale",
    }
    (doc_dir / "VALIDATED_FORWARD_SELECTION_RERUN_CONFIG.json").write_text(
        json.dumps(run_config, indent=2), encoding="utf-8"
    )

    report_lines = [
        "# Validated-layer forward-selection rerun",
        "",
        f"- Validated residual rows: {len(validated)}",
        f"- Regression-eligible parent rows: {len(parent)}",
        f"- Expected selected denominator after intercept calibration: {np.sum(p_calibrated):.6f}",
        f"- Fixed observed tomography slope: {observed_slope:.6f}",
        f"- Fixed observed Q: {observed_q:.6f}",
        f"- Peculiar-velocity convention: {VPEC_KMS:.0f} km/s",
        "",
        "## Three-scenario forward audit",
        "",
    ]
    for row in q_summary.to_dict(orient="records"):
        report_lines.extend(
            [
                f"### {row['scenario']}",
                f"- simulations: {row['n_sim_ok']}",
                f"- median Q: {row['median_Q']:.6f}",
                f"- Q >= observed: {row['n_Q_ge_observed']}/{row['n_sim_ok']}",
                f"- leading-one exceedance: {row['empirical_p_leading_one']:.6f}",
                "",
            ]
        )
    report_lines.extend(
        [
            "## Global zero-host audit",
            "",
            f"- simulations: {N_GLOBAL_NULL}",
            f"- median recovered step: {float(global_null_summary.iloc[0]['median_mass_step']):+.6f} mag",
            f"- as negative as observed: {global_extreme}/{N_GLOBAL_NULL}",
            f"- leading-one probability: {float(global_null_summary.iloc[0]['empirical_p_leading_one']):.6g}",
            "",
            "## Offset positive control",
            "",
            f"- inserted interaction: {observed_offset_interaction:+.6f}",
            f"- median recovered interaction: {float(offset_summary.iloc[0]['median_recovered_offset_interaction']):+.6f}",
            f"- positive-sign recovery fraction: {float(offset_summary.iloc[0]['fraction_recovered_positive']):.6f}",
            "",
            "Status: PASS",
        ]
    )
    (doc_dir / "VALIDATED_FORWARD_SELECTION_RERUN_REPORT.md").write_text(
        "\n".join(report_lines), encoding="utf-8"
    )

    print("Validated forward-selection rerun completed.")
    print(forward_summary.to_string(index=False))
    print(q_summary.to_string(index=False))
    print(global_null_summary.to_string(index=False))
    print(offset_summary.to_string(index=False))


if __name__ == "__main__":
    main()
