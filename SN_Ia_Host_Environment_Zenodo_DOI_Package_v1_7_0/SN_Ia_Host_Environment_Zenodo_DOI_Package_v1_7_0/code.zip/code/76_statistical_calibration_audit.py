#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Recompute the five-bin meta-regression calibration audit."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import t as student_t


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--input",
        default="results/tables/reconciliation60_best_binned_coefficients.csv",
    )
    parser.add_argument(
        "--output",
        default="results/tables/statistical_calibration_summary.csv",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    source = Path(args.input)
    output = Path(args.output)
    frame = pd.read_csv(source)

    z = frame["z_med"].to_numpy(float)
    estimate = frame["step"].to_numpy(float)
    error = frame["step_se"].to_numpy(float)
    weight = 1.0 / error**2

    design = np.column_stack(
        [np.ones(len(z)), z - np.mean(z)]
    )
    normal = design.T @ (weight[:, None] * design)
    inverse = np.linalg.inv(normal)
    beta = inverse @ (design.T @ (weight * estimate))
    residual = estimate - design @ beta
    degrees = len(z) - 2
    meta_scale = float(
        np.sum(weight * residual**2) / degrees
    )

    nominal_error = float(
        np.sqrt(inverse[1, 1] * meta_scale)
    )
    floor_error = float(
        np.sqrt(inverse[1, 1] * max(meta_scale, 1.0))
    )
    nominal_probability = float(
        2.0
        * student_t.sf(
            abs(beta[1] / nominal_error),
            degrees,
        )
    )
    floor_probability = float(
        2.0
        * student_t.sf(
            abs(beta[1] / floor_error),
            degrees,
        )
    )

    result = pd.DataFrame(
        [
            {
                "calibration": "nominal_residual_scaled",
                "slope": float(beta[1]),
                "slope_se": nominal_error,
                "p_t": nominal_probability,
                "degrees_of_freedom": degrees,
                "second_stage_variance_scale": meta_scale,
            },
            {
                "calibration": "unit_scale_floor",
                "slope": float(beta[1]),
                "slope_se": floor_error,
                "p_t": floor_probability,
                "degrees_of_freedom": degrees,
                "second_stage_variance_scale": max(
                    meta_scale,
                    1.0,
                ),
            },
        ]
    )
    output.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(output, index=False)
    print(result.to_string(index=False))


if __name__ == "__main__":
    main()
