#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
70_q1_strengthening_phase1_audits.py

Purpose
-------
Create a compact Phase-1 strengthening audit for the SN Ia host-environment
correction-validity manuscript.  The script does not replace the core analysis;
it summarizes already generated protocol tables and adds a missingness/sample
hygiene audit for reviewer-facing robustness checks.

Expected project structure
--------------------------
Run from the root of the Zenodo/release package, or pass --root:

    python scripts/70_q1_strengthening_phase1_audits.py --root .

Outputs
-------
results/tables/phase1_audit_inventory.csv
results/tables/phase1_high_roi_summary.csv
results/tables/phase1_missingness_fraction_ztf_analysis.csv
results/tables/phase1_missingness_fraction_selection_training.csv
results/tables/phase1_missingness_logit_models.csv
manuscript_insertions/phase1_results_addendum.tex
manuscript_insertions/phase1_appendix_addendum.tex
"""
from __future__ import annotations

from pathlib import Path
import argparse
import math
import numpy as np
import pandas as pd

try:
    from sklearn.linear_model import LogisticRegression
    from sklearn.metrics import roc_auc_score
    SKLEARN_OK = True
except Exception:
    SKLEARN_OK = False


def read_csv_or_none(path: Path) -> pd.DataFrame | None:
    if not path.exists():
        return None
    try:
        return pd.read_csv(path)
    except Exception:
        return None


def finite_min_max(series: pd.Series):
    s = pd.to_numeric(series, errors='coerce').replace([np.inf, -np.inf], np.nan).dropna()
    if s.empty:
        return np.nan, np.nan
    return float(s.min()), float(s.max())


def bool_exists(root: Path, rel: str) -> bool:
    return (root / rel).exists()


def missingness_fraction(df: pd.DataFrame, dataset_name: str) -> pd.DataFrame:
    rows = []
    n = len(df)
    for col in df.columns:
        miss = df[col].isna().sum()
        rows.append({
            'dataset': dataset_name,
            'column': col,
            'n': n,
            'n_missing': int(miss),
            'missing_fraction': float(miss / n) if n else np.nan,
            'n_finite_or_nonmissing': int(n - miss),
        })
    return pd.DataFrame(rows).sort_values(['missing_fraction','column'], ascending=[False, True])


def missingness_logit(df: pd.DataFrame, dataset_name: str, target_cols: list[str]) -> pd.DataFrame:
    """Small logistic audit: is availability of a field associated with z/x1/c/mass?"""
    rows = []
    predictors = [c for c in ['z', 'x1', 'c', 'host_logmass'] if c in df.columns]
    if not predictors or len(df) == 0:
        return pd.DataFrame(rows)
    Xraw = df[predictors].copy()
    for c in predictors:
        Xraw[c] = pd.to_numeric(Xraw[c], errors='coerce')
        med = Xraw[c].median(skipna=True)
        if not np.isfinite(med):
            med = 0.0
        Xraw[c] = Xraw[c].fillna(med)
        sd = Xraw[c].std(ddof=0)
        if np.isfinite(sd) and sd > 0:
            Xraw[c] = (Xraw[c] - Xraw[c].mean()) / sd
        else:
            Xraw[c] = 0.0

    for col in target_cols:
        if col not in df.columns:
            continue
        y = df[col].isna().astype(int).to_numpy()
        nmiss = int(y.sum())
        n = len(y)
        if nmiss == 0 or nmiss == n:
            rows.append({
                'dataset': dataset_name, 'target_missing_column': col, 'n': n,
                'n_missing': nmiss, 'missing_fraction': nmiss/n if n else np.nan,
                'model_status': 'not_fit_constant_missingness', 'auc': np.nan,
                'coef_z': np.nan, 'coef_x1': np.nan, 'coef_c': np.nan, 'coef_host_logmass': np.nan,
                'interpretation': 'availability is constant in this layer'
            })
            continue
        if not SKLEARN_OK:
            rows.append({
                'dataset': dataset_name, 'target_missing_column': col, 'n': n,
                'n_missing': nmiss, 'missing_fraction': nmiss/n if n else np.nan,
                'model_status': 'sklearn_unavailable', 'auc': np.nan,
                'coef_z': np.nan, 'coef_x1': np.nan, 'coef_c': np.nan, 'coef_host_logmass': np.nan,
                'interpretation': 'install scikit-learn to fit missingness audit'
            })
            continue
        try:
            clf = LogisticRegression(max_iter=2000, solver='lbfgs')
            clf.fit(Xraw[predictors], y)
            prob = clf.predict_proba(Xraw[predictors])[:, 1]
            auc = roc_auc_score(y, prob)
            coefs = dict(zip(predictors, clf.coef_[0]))
            rows.append({
                'dataset': dataset_name, 'target_missing_column': col, 'n': n,
                'n_missing': nmiss, 'missing_fraction': nmiss/n if n else np.nan,
                'model_status': 'ok', 'auc': float(auc),
                'coef_z': float(coefs.get('z', np.nan)),
                'coef_x1': float(coefs.get('x1', np.nan)),
                'coef_c': float(coefs.get('c', np.nan)),
                'coef_host_logmass': float(coefs.get('host_logmass', np.nan)),
                'interpretation': 'screening model only; high AUC means missingness is structured, not necessarily biasing the coefficient'
            })
        except Exception as exc:
            rows.append({
                'dataset': dataset_name, 'target_missing_column': col, 'n': n,
                'n_missing': nmiss, 'missing_fraction': nmiss/n if n else np.nan,
                'model_status': f'failed: {exc}', 'auc': np.nan,
                'coef_z': np.nan, 'coef_x1': np.nan, 'coef_c': np.nan, 'coef_host_logmass': np.nan,
                'interpretation': 'fit failed'
            })
    return pd.DataFrame(rows)


def summarize_existing_audits(root: Path) -> pd.DataFrame:
    tdir = root / 'results' / 'tables'
    rows = []

    # Mass-threshold sensitivity
    df = read_csv_or_none(tdir / 'protocol_mass_threshold_sensitivity.csv')
    if df is not None and len(df):
        slope_min, slope_max = finite_min_max(df['tomography_slope'])
        pmin, pmax = finite_min_max(df['heterogeneity_p'])
        step_min, step_max = finite_min_max(df['global_step'])
        thresholds = ', '.join(f"{x:.2f}" for x in pd.to_numeric(df['threshold'], errors='coerce').dropna().tolist())
        rows.append({
            'audit': 'mass_threshold_sensitivity', 'status': 'available',
            'n_rows': len(df),
            'key_result': f'thresholds={thresholds}; global steps negative ({step_min:.4f} to {step_max:.4f}); tomography slopes positive ({slope_min:.3f} to {slope_max:.3f}); heterogeneity p range {pmin:.3g}--{pmax:.3g}',
            'main_text_use': 'One sentence in Results; full table in Appendix.'
        })
    else:
        rows.append({'audit':'mass_threshold_sensitivity','status':'missing','n_rows':0,'key_result':'not found','main_text_use':'run threshold grid'})

    # Redshift bin robustness
    df = read_csv_or_none(tdir / 'protocol_redshift_bin_robustness_summary.csv')
    if df is not None and len(df):
        slope_min, slope_max = finite_min_max(df['tomography_slope'])
        pmin, pmax = finite_min_max(df['heterogeneity_p'])
        rows.append({
            'audit': 'redshift_binning_robustness', 'status': 'available',
            'n_rows': len(df),
            'key_result': f'3--6 bins, equal-N and fixed-width; all slopes positive ({slope_min:.3f} to {slope_max:.3f}); heterogeneity p range {pmin:.3g}--{pmax:.3g}',
            'main_text_use': 'One sentence in Results; full grid in Appendix.'
        })
    else:
        rows.append({'audit':'redshift_binning_robustness','status':'missing','n_rows':0,'key_result':'not found','main_text_use':'run binning grid'})

    # Low-z and peculiar velocity
    df = read_csv_or_none(tdir / 'protocol_lowz_pecvel_stress_summary.csv')
    if df is not None and len(df):
        slope_min, slope_max = finite_min_max(df['tomography_slope'])
        pmin, pmax = finite_min_max(df['heterogeneity_p'])
        cuts = ', '.join(str(x) for x in sorted(df['lowz_cut'].astype(str).unique()))
        vpec = ', '.join(str(int(x)) for x in sorted(pd.to_numeric(df['vpec_kms'], errors='coerce').dropna().unique()))
        rows.append({
            'audit': 'lowz_peculiar_velocity_stress', 'status': 'available',
            'n_rows': len(df),
            'key_result': f'low-z cuts={cuts}; vpec={vpec} km/s; slopes positive ({slope_min:.3f} to {slope_max:.3f}); heterogeneity p range {pmin:.3g}--{pmax:.3g}',
            'main_text_use': 'One sentence in Results; full grid in Appendix.'
        })
    else:
        rows.append({'audit':'lowz_peculiar_velocity_stress','status':'missing','n_rows':0,'key_result':'not found','main_text_use':'run low-z/vpec grid'})

    # Hierarchical nonstationarity
    df = read_csv_or_none(tdir / 'protocol_hierarchical_nonstationarity.csv')
    if df is not None and len(df):
        sigmin, sigmax = finite_min_max(df['sigma_delta_z_mle'])
        pmin, pmax = finite_min_max(df['LR_p_approx_chi2_1'])
        rows.append({
            'audit': 'hierarchical_redshift_nonstationarity', 'status': 'available',
            'n_rows': len(df),
            'key_result': f'sigma_delta_z MLE {sigmin:.4f}--{sigmax:.4f} mag; approximate LR p range {pmin:.3g}--{pmax:.3g}; strongest for lower bin counts',
            'main_text_use': 'Appendix/supporting audit only; do not overclaim posterior significance.'
        })
    else:
        rows.append({'audit':'hierarchical_redshift_nonstationarity','status':'missing','n_rows':0,'key_result':'not found','main_text_use':'optional hierarchical audit'})

    # Selection forward
    perf = read_csv_or_none(tdir / 'empirical_selection_model_performance.csv')
    summ = read_csv_or_none(tdir / 'forward_selection_simulation_summary.csv')
    if perf is not None and summ is not None and len(perf) and len(summ):
        auc = float(perf.iloc[0].get('auc', np.nan))
        brier = float(perf.iloc[0].get('brier_score', np.nan))
        parts = []
        for _, r in summ.iterrows():
            parts.append(f"{r['scenario']}: median slope={float(r['median_tomography_slope']):+.3f}, frac>=obs={float(r['fraction_tomography_slope_ge_observed']):.4f}")
        rows.append({
            'audit': 'empirical_selection_forward', 'status': 'available',
            'n_rows': len(summ),
            'key_result': f'AUC={auc:.4f}, Brier={brier:.4f}; ' + '; '.join(parts),
            'main_text_use': 'Keep in Results; supports selection surface alone insufficient.'
        })
    else:
        rows.append({'audit':'empirical_selection_forward','status':'missing','n_rows':0,'key_result':'not found','main_text_use':'run empirical selection forward model'})

    # Selection model calibration
    df = read_csv_or_none(tdir / 'empirical_selection_model_calibration.csv')
    if df is not None and len(df):
        # Simple mean absolute calibration error across bins.
        ece = np.average(np.abs(df['mean_predicted_probability'] - df['observed_selected_fraction']), weights=df['n'])
        rows.append({
            'audit': 'selection_calibration_curve', 'status': 'available',
            'n_rows': len(df),
            'key_result': f'10-bin reliability table available; weighted mean absolute calibration difference={ece:.4f}',
            'main_text_use': 'Appendix only; useful for selection-stress credibility.'
        })
    else:
        rows.append({'audit':'selection_calibration_curve','status':'missing','n_rows':0,'key_result':'not found','main_text_use':'optional calibration table'})

    # Environmental ladder
    df = read_csv_or_none(tdir / 'protocol_environmental_decomposition_ladder.csv')
    boot = read_csv_or_none(tdir / 'protocol_interaction_bootstrap_summary.csv')
    if df is not None and len(df):
        best = df.sort_values('rms').iloc[0] if 'rms' in df.columns else None
        btxt = ''
        if boot is not None and len(boot) and 'term' in boot.columns:
            rr = boot[boot['term'].astype(str).eq('H_dlr')]
            if len(rr):
                r = rr.iloc[0]
                btxt = f"; H_dlr bootstrap median={float(r['median']):+.4f}, 95% [{float(r['p025']):+.4f},{float(r['p975']):+.4f}], positive fraction={float(r['frac_positive']):.3f}"
        rows.append({
            'audit': 'environmental_decomposition_ladder', 'status': 'available',
            'n_rows': len(df),
            'key_result': f'best RMS model={best.get("model", "unknown") if best is not None else "unknown"}, RMS={float(best.get("rms", np.nan)):.4f}' + btxt,
            'main_text_use': 'Keep compact Results paragraph; table/bootstraps in Appendix.'
        })
    else:
        rows.append({'audit':'environmental_decomposition_ladder','status':'missing','n_rows':0,'key_result':'not found','main_text_use':'run environmental ladder'})

    # Leave-one-bin-out
    df = read_csv_or_none(tdir / 'reconciliation_leave_one_bin_out.csv')
    if df is not None and len(df):
        pmin, pmax = finite_min_max(df['slope_p_t_df_bins_minus_2'])
        rows.append({
            'audit': 'leave_one_bin_out', 'status': 'available',
            'n_rows': len(df),
            'key_result': f'leave-one-bin-out table available; t-calibrated slope p range {pmin:.3g}--{pmax:.3g}; shows lowest-bin dependence should be described transparently',
            'main_text_use': 'Appendix; mention lowest-redshift anchor if needed.'
        })
    else:
        rows.append({'audit':'leave_one_bin_out','status':'missing','n_rows':0,'key_result':'not found','main_text_use':'run leave-one-bin-out audit'})

    # Toy systematic budget
    df = read_csv_or_none(tdir / 'protocol_toy_systematic_budget.csv')
    if df is not None and len(df):
        hmin, hmax = finite_min_max(df['toy_delta_H0_over_H0_percent'])
        rows.append({
            'audit': 'distance_scale_sensitivity', 'status': 'available',
            'n_rows': len(df),
            'key_result': f'bin-level toy delta_H0/H0 range {hmin:+.3f}% to {hmax:+.3f}% under scalar reference convention',
            'main_text_use': 'Keep diagnostic-only wording; no H0 claim.'
        })
    else:
        rows.append({'audit':'distance_scale_sensitivity','status':'missing','n_rows':0,'key_result':'not found','main_text_use':'optional toy sensitivity table'})

    # Explicitly mark missing high-ROI audits not in package.
    for audit, use in [
        ('selection_stress_for_heterogeneity_Q', 'Recommended next computation: simulate Q directly, not only slope.'),
        ('object_level_jackknife_influence', 'Recommended next computation if official object-level residual file is available.'),
        ('local_proxy_stratified_mass_steps', 'Recommended next computation; can strengthen environmental interpretation.'),
        ('covariate_balance_love_plot', 'Optional; use as Appendix matching/balance audit.'),
    ]:
        expected = False
        if audit == 'selection_stress_for_heterogeneity_Q':
            # Search for Q columns in available selection draw files.
            for rel in ['results/tables/forward_selection_simulation_draws.csv', 'results/tables/selection_null_simulation_draws.csv']:
                d = read_csv_or_none(root / rel)
                if d is not None and any('heterogeneity' in c.lower() or c.lower() == 'q' for c in d.columns):
                    expected = True
        rows.append({
            'audit': audit,
            'status': 'available' if expected else 'not_yet_available',
            'n_rows': 0,
            'key_result': 'Q columns found in selection draws' if expected else 'not found in current release tables',
            'main_text_use': use
        })

    return pd.DataFrame(rows)


def make_inventory(root: Path) -> pd.DataFrame:
    required = [
        'results/tables/protocol_mass_threshold_sensitivity.csv',
        'results/tables/protocol_redshift_bin_robustness_summary.csv',
        'results/tables/protocol_lowz_pecvel_stress_summary.csv',
        'results/tables/protocol_hierarchical_nonstationarity.csv',
        'results/tables/reconciliation_leave_one_bin_out.csv',
        'results/tables/empirical_selection_model_performance.csv',
        'results/tables/empirical_selection_model_calibration.csv',
        'results/tables/forward_selection_simulation_summary.csv',
        'results/tables/protocol_environmental_decomposition_ladder.csv',
        'results/tables/protocol_interaction_bootstrap_summary.csv',
        'results/tables/protocol_toy_systematic_budget.csv',
        'data/processed/ZTF_DR2_analysis_sample.csv',
        'results/tables/empirical_selection_training_sample.csv',
    ]
    rows = []
    for rel in required:
        p = root / rel
        rows.append({
            'path': rel,
            'exists': p.exists(),
            'bytes': p.stat().st_size if p.exists() else 0,
        })
    return pd.DataFrame(rows)


def write_latex_insertions(root: Path, outdir: Path, summary: pd.DataFrame):
    tdir = root / 'results' / 'tables'
    thresh = read_csv_or_none(tdir / 'protocol_mass_threshold_sensitivity.csv')
    binrob = read_csv_or_none(tdir / 'protocol_redshift_bin_robustness_summary.csv')
    lowz = read_csv_or_none(tdir / 'protocol_lowz_pecvel_stress_summary.csv')
    hier = read_csv_or_none(tdir / 'protocol_hierarchical_nonstationarity.csv')
    sel = read_csv_or_none(tdir / 'forward_selection_simulation_summary.csv')
    perf = read_csv_or_none(tdir / 'empirical_selection_model_performance.csv')
    cal = read_csv_or_none(tdir / 'empirical_selection_model_calibration.csv')

    def rng(df, col):
        if df is None or col not in df:
            return (np.nan, np.nan)
        return finite_min_max(df[col])

    slope_t = rng(thresh, 'tomography_slope')
    het_t = rng(thresh, 'heterogeneity_p')
    slope_b = rng(binrob, 'tomography_slope')
    het_b = rng(binrob, 'heterogeneity_p')
    slope_l = rng(lowz, 'tomography_slope')
    het_l = rng(lowz, 'heterogeneity_p')
    sig_h = rng(hier, 'sigma_delta_z_mle')
    hp_h = rng(hier, 'LR_p_approx_chi2_1')

    auc = brier = np.nan
    if perf is not None and len(perf):
        auc = float(perf.iloc[0].get('auc', np.nan)); brier = float(perf.iloc[0].get('brier_score', np.nan))
    ece = np.nan
    if cal is not None and len(cal):
        ece = float(np.average(np.abs(cal['mean_predicted_probability']-cal['observed_selected_fraction']), weights=cal['n']))

    main = rf"""
% Phase-1 strengthening insertion for Section 4.2/4.3.
% Keep this compact in the main text; place full tables in the Appendix.
Additional protocol audits support the same qualitative interpretation. Across host-mass thresholds from $
obreak	houghspace 9.5$ to 10.5, the global step remains negative and the tomographic slopes remain positive ({slope_t[0]:.3f}--{slope_t[1]:.3f} mag per unit redshift), with heterogeneity probabilities spanning {het_t[0]:.3g}--{het_t[1]:.3g}. Alternative 3--6 bin equal-number and fixed-width redshift partitions likewise preserve positive slopes ({slope_b[0]:.3f}--{slope_b[1]:.3f}) and significant or near-significant heterogeneity ({het_b[0]:.3g}--{het_b[1]:.3g}). Low-redshift and peculiar-velocity stress tests retain positive slopes ({slope_l[0]:.3f}--{slope_l[1]:.3f}) over the tested choices. A hierarchical bin-scatter audit gives $
obreak\sigma_{{\Delta,z}}\simeq {sig_h[0]:.3f}$--${sig_h[1]:.3f}$ mag, with the strongest support in the lower-bin-count configurations. These tests are not promoted to new discovery claims; they show that the redshift-local coefficient instability is not tied to one threshold, one binning, or one low-redshift convention.

The empirical selection model has AUC={auc:.4f}, Brier score={brier:.4f}, and a 10-bin calibration audit with weighted mean absolute calibration difference {ece:.4f}. The forward simulations reported in Table~\ref{{tab:empirical_selection_forward}} are therefore interpreted as a selection-stress audit of the measured raw-to-final surface rather than as an end-to-end survey simulation.
""".strip()+"\n"

    appendix = r"""
\section{Phase-1 strengthening audit tables}
\label{app:phase1_strengthening}

This appendix collects compact robustness audits added during the Phase-1 strengthening pass. These audits are supporting checks; they do not change the primary interpretation based on the validated residual-layer reconciliation.

\subsection{Threshold, binning, low-redshift, and velocity stress tests}
\label{app:threshold_binning_lowz}

The threshold-sensitivity table tests whether the host-mass result depends on the conventional $\log(M_\star/M_\odot)=10$ split. The redshift-binning table tests 3--6 bin equal-number and fixed-width partitions. The low-redshift/peculiar-velocity table tests whether the lowest-redshift anchor is artificially amplified by peculiar-velocity weighting. Machine-readable versions are provided as:
\begin{itemize}
\item \texttt{protocol\_mass\_threshold\_sensitivity.csv},
\item \texttt{protocol\_redshift\_bin\_robustness\_summary.csv},
\item \texttt{protocol\_lowz\_pecvel\_stress\_summary.csv}.
\end{itemize}

\subsection{Hierarchical redshift-bin scatter}
\label{app:hierarchical_bin_scatter}

The hierarchical audit treats the redshift-bin coefficients as draws from a common distribution with extra bin-to-bin scatter $\sigma_{\Delta,z}$. It is used as a supporting model-adequacy check, not as the headline detection statistic. The machine-readable table is \texttt{protocol\_hierarchical\_nonstationarity.csv}.

\subsection{Missingness and selection-calibration audits}
\label{app:missingness_selection_calibration}

Missingness fractions for the ZTF residual and selection-training layers are reported in \texttt{phase1\_missingness\_fraction\_ztf\_analysis.csv} and \texttt{phase1\_missingness\_fraction\_selection\_training.csv}. Logistic missingness screens are reported in \texttt{phase1\_missingness\_logit\_models.csv}. These tests are sample-construction diagnostics and are not interpreted as causal missingness models.
""".strip()+"\n"

    (outdir / 'manuscript_insertions' / 'phase1_results_addendum.tex').write_text(main, encoding='utf-8')
    (outdir / 'manuscript_insertions' / 'phase1_appendix_addendum.tex').write_text(appendix, encoding='utf-8')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', default='.', help='Project/release package root')
    ap.add_argument('--outdir', default='.', help='Output root')
    args = ap.parse_args()

    root = Path(args.root).resolve()
    outdir = Path(args.outdir).resolve()
    (outdir / 'results' / 'tables').mkdir(parents=True, exist_ok=True)
    (outdir / 'manuscript_insertions').mkdir(parents=True, exist_ok=True)

    inv = make_inventory(root)
    inv.to_csv(outdir / 'results' / 'tables' / 'phase1_audit_inventory.csv', index=False)

    summ = summarize_existing_audits(root)
    summ.to_csv(outdir / 'results' / 'tables' / 'phase1_high_roi_summary.csv', index=False)

    # Missingness audits.
    ztf = read_csv_or_none(root / 'data' / 'processed' / 'ZTF_DR2_analysis_sample.csv')
    sel = read_csv_or_none(root / 'results' / 'tables' / 'empirical_selection_training_sample.csv')
    logit_rows = []
    target_cols = ['host_logmass','local_color','host_dlr','log1p_host_dlr','x1','c','mb','mb_err','lc_chi2_red']
    if ztf is not None:
        missingness_fraction(ztf, 'ZTF_DR2_analysis_sample').to_csv(
            outdir / 'results' / 'tables' / 'phase1_missingness_fraction_ztf_analysis.csv', index=False)
        logit_rows.append(missingness_logit(ztf, 'ZTF_DR2_analysis_sample', target_cols))
    if sel is not None:
        missingness_fraction(sel, 'empirical_selection_training_sample').to_csv(
            outdir / 'results' / 'tables' / 'phase1_missingness_fraction_selection_training.csv', index=False)
        logit_rows.append(missingness_logit(sel, 'empirical_selection_training_sample', target_cols))
    if logit_rows:
        pd.concat([d for d in logit_rows if d is not None and len(d)], ignore_index=True).to_csv(
            outdir / 'results' / 'tables' / 'phase1_missingness_logit_models.csv', index=False)

    write_latex_insertions(root, outdir, summ)

    print('Phase-1 strengthening audit completed.')
    print(f'Root: {root}')
    print(f'Output: {outdir}')

if __name__ == '__main__':
    main()
