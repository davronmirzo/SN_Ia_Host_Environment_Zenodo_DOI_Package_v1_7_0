#!/usr/bin/env python
# -*- coding: utf-8 -*-
r"""Run the Phase-4 environment stratification and interaction audit.

Windows example
---------------
python code/74_environment_stratification_interaction.py ^
  --input "data\processed\ZTF_DR2_validated_residual_layer.csv" ^
  --outdir "rerun_phase4" ^
  --n-bootstrap 2000 ^
  --n-permutation 5000 ^
  --seed 20260716
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import chi2, t as student_t
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--outdir", required=True)
    parser.add_argument("--n-bootstrap", type=int, default=2000)
    parser.add_argument("--n-permutation", type=int, default=5000)
    parser.add_argument("--seed", type=int, default=20260716)
    return parser.parse_args()


def fit_wls(
    frame: pd.DataFrame,
    columns: list[str],
    extra_weight: np.ndarray | None = None,
) -> dict[str, object]:
    y = frame["residual"].to_numpy(float)
    X = np.column_stack(
        [np.ones(len(frame))]
        + [frame[column].to_numpy(float) for column in columns]
    )
    weight = 1.0 / np.maximum(
        frame["residual_err"].to_numpy(float),
        1.0e-4,
    ) ** 2
    if extra_weight is not None:
        weight = weight * np.asarray(extra_weight, dtype=float)
    normal = X.T @ (weight[:, None] * X)
    inverse = np.linalg.pinv(normal)
    beta = inverse @ (X.T @ (weight * y))
    residual = y - X @ beta
    dof = len(frame) - X.shape[1]
    chi2_red = float(np.sum(weight * residual**2) / dof)
    covariance = inverse * chi2_red
    standard_error = np.sqrt(np.diag(covariance))
    probability = 2.0 * student_t.sf(
        np.abs(beta / standard_error),
        dof,
    )
    return {
        "columns": ["intercept"] + columns,
        "beta": beta,
        "standard_error": standard_error,
        "probability": probability,
        "covariance": covariance,
        "rms": float(np.sqrt(np.mean(residual**2))),
        "nmad": float(
            1.4826
            * np.median(
                np.abs(residual - np.median(residual))
            )
        ),
        "chi2_red": chi2_red,
        "n": len(frame),
    }


def coefficient(
    result: dict[str, object],
    term: str,
) -> tuple[float, float, float]:
    index = result["columns"].index(term)
    return (
        float(result["beta"][index]),
        float(result["standard_error"][index]),
        float(result["probability"][index]),
    )


def fit_mass_step(frame: pd.DataFrame) -> dict[str, float | int]:
    result = fit_wls(frame, ["x1", "c", "H"])
    estimate, error, probability = coefficient(result, "H")
    return {
        "n": int(result["n"]),
        "mass_step": estimate,
        "mass_step_se": error,
        "mass_step_p": probability,
        "rms": float(result["rms"]),
        "nmad": float(result["nmad"]),
        "chi2_red": float(result["chi2_red"]),
        "z_median": float(frame["z"].median()),
        "high_mass_fraction": float(frame["H"].mean()),
    }


def freedman_lane(
    frame: pd.DataFrame,
    reduced_columns: list[str],
    full_columns: list[str],
    tested_term: str,
    n_permutation: int,
    seed: int,
) -> tuple[float, np.ndarray, float]:
    y = frame["residual"].to_numpy(float)
    weight = 1.0 / np.maximum(
        frame["residual_err"].to_numpy(float),
        1.0e-4,
    ) ** 2
    sqrt_weight = np.sqrt(weight)
    y_weighted = y * sqrt_weight
    reduced = np.column_stack(
        [np.ones(len(frame))]
        + [
            frame[column].to_numpy(float)
            for column in reduced_columns
        ]
    ) * sqrt_weight[:, None]
    full = np.column_stack(
        [np.ones(len(frame))]
        + [
            frame[column].to_numpy(float)
            for column in full_columns
        ]
    ) * sqrt_weight[:, None]
    reduced_beta, *_ = np.linalg.lstsq(
        reduced,
        y_weighted,
        rcond=None,
    )
    fitted = reduced @ reduced_beta
    residual = y_weighted - fitted
    projection = np.linalg.pinv(full.T @ full) @ full.T
    term_index = 1 + full_columns.index(tested_term)
    observed = float((projection @ y_weighted)[term_index])
    rng = np.random.default_rng(seed)
    draws = np.empty(n_permutation, dtype=float)
    for index in range(n_permutation):
        draws[index] = float(
            (
                projection
                @ (fitted + rng.permutation(residual))
            )[term_index]
        )
    probability = float(
        (
            1
            + np.sum(np.abs(draws) >= abs(observed))
        )
        / (n_permutation + 1)
    )
    return observed, draws, probability


def main() -> None:
    args = parse_args()
    input_file = Path(args.input).expanduser().resolve()
    outdir = Path(args.outdir).expanduser().resolve()
    table_dir = outdir / "results" / "tables"
    figure_dir = outdir / "figures"
    doc_dir = outdir / "docs"
    for directory in (table_dir, figure_dir, doc_dir):
        directory.mkdir(parents=True, exist_ok=True)

    data = pd.read_csv(input_file).reset_index(drop=True)
    data["H"] = (data["host_logmass"] >= 10.0).astype(float)
    data["z_c"] = data["z"] - data["z"].mean()
    data["local_c"] = (
        data["local_color"]
        - data["local_color"].mean(skipna=True)
    )
    data["R_c"] = (
        data["log1p_host_dlr"]
        - data["log1p_host_dlr"].mean()
    )
    data["H_z"] = data["H"] * data["z_c"]
    data["H_local"] = data["H"] * data["local_c"]
    data["H_R"] = data["H"] * data["R_c"]
    data["H_c"] = data["H"] * data["c"]
    data["H_x1"] = data["H"] * data["x1"]
    complete = data.dropna(subset=["local_color"]).copy()

    offset_columns = ["x1", "c", "H", "R_c", "H_R"]
    local_columns = ["x1", "c", "H", "local_c", "H_local"]
    full_columns = [
        "x1",
        "c",
        "H",
        "z_c",
        "local_c",
        "R_c",
        "H_z",
        "H_local",
        "H_R",
        "H_c",
        "H_x1",
    ]
    offset_fit = fit_wls(data, offset_columns)
    local_fit = fit_wls(complete, local_columns)
    full_fit = fit_wls(complete, full_columns)

    local_median = float(
        data["local_color"].median(skipna=True)
    )
    rows = []
    definitions = [
        (
            "inner_host",
            data["host_dlr"] < 1.0,
        ),
        (
            "outer_host",
            data["host_dlr"] >= 1.0,
        ),
        (
            "low_local_colour",
            data["local_color"] < local_median,
        ),
        (
            "high_local_colour",
            data["local_color"] >= local_median,
        ),
    ]
    for name, mask in definitions:
        result = fit_mass_step(data.loc[mask].copy())
        result["stratum"] = name
        rows.append(result)
    stratified = pd.DataFrame(rows)
    stratified.to_csv(
        table_dir / "phase4_stratified_mass_steps.csv",
        index=False,
    )

    interaction_rows = []
    for model_name, result, terms in [
        (
            "offset_interaction_simple",
            offset_fit,
            ["H", "R_c", "H_R"],
        ),
        (
            "local_colour_interaction_simple",
            local_fit,
            ["H", "local_c", "H_local"],
        ),
        (
            "full_environment_complete_case",
            full_fit,
            ["H", "H_z", "H_local", "H_R", "H_c", "H_x1"],
        ),
    ]:
        for term in terms:
            estimate, error, probability = coefficient(
                result,
                term,
            )
            interaction_rows.append(
                {
                    "model": model_name,
                    "n": int(result["n"]),
                    "term": term,
                    "coefficient": estimate,
                    "standard_error": error,
                    "p_value": probability,
                }
            )
    pd.DataFrame(interaction_rows).to_csv(
        table_dir / "phase4_global_interactions.csv",
        index=False,
    )

    _, offset_null, offset_probability = freedman_lane(
        data,
        ["x1", "c", "H", "R_c"],
        offset_columns,
        "H_R",
        args.n_permutation,
        args.seed + 100,
    )
    _, local_null, local_probability = freedman_lane(
        complete,
        ["x1", "c", "H", "local_c"],
        local_columns,
        "H_local",
        args.n_permutation,
        args.seed + 200,
    )
    pd.DataFrame(
        {
            "draw_id": np.arange(args.n_permutation),
            "offset_interaction_H_R_null": offset_null,
            "local_interaction_H_local_null": local_null,
        }
    ).to_csv(
        table_dir / "phase4_permutation_draws.csv",
        index=False,
    )
    pd.DataFrame(
        [
            {
                "term": "H_R",
                "empirical_p_two_sided": offset_probability,
            },
            {
                "term": "H_local",
                "empirical_p_two_sided": local_probability,
            },
        ]
    ).to_csv(
        table_dir / "phase4_permutation_summary.csv",
        index=False,
    )

    print("Phase-4 environment audit completed.")
    print(f"Input: {input_file}")
    print(f"Output: {outdir}")
    print(
        "Mass-offset interaction: "
        f"{coefficient(offset_fit, 'H_R')[0]:+.6f} +/- "
        f"{coefficient(offset_fit, 'H_R')[1]:.6f}"
    )
    print(
        "Permutation p: "
        f"{offset_probability:.6g}"
    )


if __name__ == "__main__":
    main()
