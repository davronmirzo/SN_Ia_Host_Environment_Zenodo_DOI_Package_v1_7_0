from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyArrowPatch

OUT = Path(__file__).resolve().parents[1] / "figures"
PDF_OUT = OUT / "fig01_analysis_flow.pdf"
PNG_OUT = OUT / "fig01_analysis_flow_preview.png"

INK = "black"

fig, ax = plt.subplots(figsize=(14.2, 7.2))
ax.set_xlim(0, 1)
ax.set_ylim(0, 1)
ax.axis("off")

def box(x, y, w, h, lw=1.15):
    patch = Rectangle(
        (x, y), w, h,
        fill=False,
        edgecolor=INK,
        linewidth=lw,
        joinstyle="round",
        zorder=3,
    )
    ax.add_patch(patch)
    return patch

def add_title_body(x, y, w, h, title, body, title_size=10.2, body_size=8.2,
                   title_y_frac=0.82, body_y_frac=0.43):
    ax.text(
        x + w/2, y + h*title_y_frac, title,
        ha="center", va="center",
        fontsize=title_size, fontweight="bold",
        linespacing=1.05, color=INK, zorder=4,
    )
    ax.text(
        x + w/2, y + h*body_y_frac, body,
        ha="center", va="center",
        fontsize=body_size,
        linespacing=1.22, color=INK, zorder=4,
    )

def line(points, lw=0.95, z=1):
    xs, ys = zip(*points)
    ax.plot(
        xs, ys,
        linewidth=lw,
        color=INK,
        zorder=z,
        solid_capstyle="round",
    )

def arrow(start, end, lw=0.95, mutation_scale=8, z=2):
    ax.add_patch(FancyArrowPatch(
        start, end,
        arrowstyle="-|>",
        mutation_scale=mutation_scale,
        linewidth=lw,
        color=INK,
        shrinkA=0, shrinkB=0,
        zorder=z,
    ))

# -------------------- Input layer --------------------
top_y, top_h = 0.815, 0.125
top_boxes = [
    (0.045, top_y, 0.275, top_h,
     "Primary ZTF residual layer\n$N=2642$",
     "Validated residuals with\nhost and local proxies"),
    (0.365, top_y, 0.270, top_h,
     "ZTF selection layer\n$N=3483$; 2670 selected",
     "Raw-to-final labels and\nselection covariates"),
    (0.680, top_y, 0.275, top_h,
     "External products",
     "Pantheon+  $N=559$\nDES-SN5YR  $N=1829$\nFinal residual products"),
]
for x, y, w, h, title, body in top_boxes:
    box(x, y, w, h, lw=1.25)
    add_title_body(
        x, y, w, h, title, body,
        title_size=10.8, body_size=9.15,
        title_y_frac=0.77, body_y_frac=0.30
    )

# -------------------- Analysis layer --------------------
mid_y, mid_h = 0.335, 0.365
gap = 0.012
left = 0.035
w = (0.93 - 4*gap) / 5
xs = [left + i*(w+gap) for i in range(5)]

titles = [
    "Global host residual",
    "Redshift stability",
    "Selection-forward and\ninfluence diagnostics",
    "Environmental structure",
    "External-product audit",
]
bodies = [
    "Host-mass step and\ncontinuous mass slope\n\nAlternative binning and\nmass-threshold tests\n\nSecure global residual",
    "Five-bin coefficient\nsequence\n\nCorrection and\nbootstrap checks\n\nNo unique smooth law",
    "Selection: forward simulations\nand positive controls\n\nInfluence: leave-one-out,\nleverage, and residual checks\n\nNull inputs rarely reproduce\nthe observed structure",
    "Inner-outer host steps\n\nMass-offset interaction\nand robustness tests\n\nStrong, sign-consistent\nmass-offset coupling",
    "Within-product tomography\n\nBootstrap and\nleave-one-out checks\n\nProduct-level context,\nnot direct replication",
]

for i, (x, title, body) in enumerate(zip(xs, titles, bodies)):
    box(x, mid_y, w, mid_h, lw=1.1)
    add_title_body(
        x, mid_y, w, mid_h, title, body,
        title_size=10.0 if i != 2 else 9.65,
        body_size=8.55 if i != 2 else 8.05,
        title_y_frac=0.885,
        body_y_frac=0.43,
    )
    ax.plot(
        [x + 0.08*w, x + 0.92*w],
        [mid_y + 0.755*mid_h, mid_y + 0.755*mid_h],
        linewidth=0.65, color=INK, zorder=3
    )

# -------------------- Input-to-analysis mapping --------------------
mid_top = mid_y + mid_h
branch_centres = [x + w/2 for x in xs]

# Primary ZTF residual layer -> global, redshift, influence, environmental.
primary_origin = (top_boxes[0][0] + top_boxes[0][2]/2, top_y)
primary_bus_y = 0.765
line([primary_origin, (primary_origin[0], primary_bus_y)], lw=1.0)
line([(branch_centres[0], primary_bus_y),
      (branch_centres[3], primary_bus_y)], lw=1.0)
line([(primary_origin[0], primary_bus_y),
      (branch_centres[0], primary_bus_y)], lw=1.0)

for idx in [0, 1, 3]:
    line([(branch_centres[idx], primary_bus_y),
          (branch_centres[idx], mid_top + 0.018)], lw=0.95)
    arrow((branch_centres[idx], mid_top + 0.018),
          (branch_centres[idx], mid_top), lw=0.95)

# Primary residual entry to the left side of branch 3: influence diagnostics.
x3_left_entry = xs[2] + 0.34*w
line([(x3_left_entry, primary_bus_y),
      (x3_left_entry, mid_top + 0.018)], lw=0.95)
arrow((x3_left_entry, mid_top + 0.018),
      (x3_left_entry, mid_top), lw=0.95)

# ZTF selection layer entry to the right side of branch 3: selection-forward tests.
selection_origin = (top_boxes[1][0] + top_boxes[1][2]/2, top_y)
x3_right_entry = xs[2] + 0.66*w
selection_route_y = 0.735
line([
    selection_origin,
    (selection_origin[0], selection_route_y),
    (x3_right_entry, selection_route_y),
    (x3_right_entry, mid_top + 0.018),
], lw=1.0)
arrow((x3_right_entry, mid_top + 0.018),
      (x3_right_entry, mid_top), lw=1.0)

# External products -> external-product audit.
external_origin = (top_boxes[2][0] + top_boxes[2][2]/2, top_y)
line([
    external_origin,
    (external_origin[0], 0.745),
    (branch_centres[4], 0.745),
    (branch_centres[4], mid_top + 0.018),
], lw=1.0)
arrow((branch_centres[4], mid_top + 0.018),
      (branch_centres[4], mid_top), lw=1.0)

ax.text(
    x3_left_entry - 0.007, mid_top + 0.028, "influence",
    ha="right", va="bottom", fontsize=7.8, color=INK
)
ax.text(
    x3_right_entry + 0.007, mid_top + 0.028, "selection",
    ha="left", va="bottom", fontsize=7.8, color=INK
)

# -------------------- Verdict layer --------------------
verdict_x, verdict_y, verdict_w, verdict_h = 0.055, 0.075, 0.89, 0.155
verdict_top = verdict_y + verdict_h

for centre in branch_centres:
    arrow((centre, mid_y), (centre, verdict_top),
          lw=0.8, mutation_scale=7, z=1)

box(verdict_x, verdict_y, verdict_w, verdict_h, lw=1.3)
ax.text(
    verdict_x + 0.025, verdict_y + verdict_h*0.76,
    "Correction-validity verdict",
    ha="left", va="center",
    fontsize=11.2, fontweight="bold", color=INK, zorder=4,
)
ax.plot(
    [verdict_x + 0.025, verdict_x + verdict_w - 0.025],
    [verdict_y + verdict_h*0.61, verdict_y + verdict_h*0.61],
    linewidth=0.75, color=INK, zorder=3
)
ax.text(
    verdict_x + verdict_w/2, verdict_y + verdict_h*0.30,
    "The global host-mass residual is secure; projected host offset adds additional structure,\n"
    "but a stable survey-universal redshift correction is not validated.",
    ha="center", va="center",
    fontsize=10.0, linespacing=1.18, color=INK, zorder=4,
)

fig.savefig(PDF_OUT, bbox_inches="tight", pad_inches=0.10)
fig.savefig(PNG_OUT, dpi=320, bbox_inches="tight", pad_inches=0.10)
plt.close(fig)

print(f"Created {PDF_OUT} and {PNG_OUT}")
