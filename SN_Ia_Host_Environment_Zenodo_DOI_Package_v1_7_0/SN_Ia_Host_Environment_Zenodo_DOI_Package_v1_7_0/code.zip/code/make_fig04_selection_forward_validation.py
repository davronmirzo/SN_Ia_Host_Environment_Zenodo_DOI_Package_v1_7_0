#!/usr/bin/env python
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "results/tables/forward_selection_simulation_draws.csv"
OUT = ROOT / "figures/fig04_selection_forward_validation.pdf"

df = pd.read_csv(DATA)
scenario_order = [
    "zero_mass_effect",
    "constant_official_mass_step",
    "observed_validated_tomographic_mass_step",
]
display_labels = ["Zero effect", "Constant step", "Validated\ntomography"]
y_positions = np.arange(len(scenario_order))[::-1]
observed_slope = float(df["observed_tomography_slope"].iloc[0])
observed_q = float(df["observed_heterogeneity_Q"].iloc[0])

medians, lower, upper, q_plot = [], [], [], []
for scenario in scenario_order:
    group = df.loc[df["scenario"] == scenario]
    slopes = group["tomography_slope"].to_numpy(float)
    median = float(np.median(slopes))
    p16, p84 = np.percentile(slopes, [16, 84])
    medians.append(median)
    lower.append(median - p16)
    upper.append(p84 - median)
    q_plot.append(group["heterogeneity_Q"].to_numpy(float))

fig, axes = plt.subplots(1, 2, figsize=(12.6, 5.25))
axes[0].errorbar(
    medians, y_positions, xerr=np.vstack([lower, upper]),
    fmt="o", capsize=5, markersize=7, linewidth=1.7,
)
axes[0].axvline(observed_slope, linestyle="--", linewidth=1.5)
axes[0].axvline(0.0, linewidth=1.0)
axes[0].set_yticks(y_positions, labels=display_labels)
axes[0].set_xlabel(
    "Recovered slope (mag per unit redshift)",
    fontsize=15.5, fontweight="bold", labelpad=8,
)
axes[0].set_title("Validated fixed-edge recovery", fontsize=17, pad=10)

axes[1].boxplot(
    q_plot,
    tick_labels=["Zero\neffect", "Constant\nstep", "Validated\ntomography"],
    showfliers=False, widths=0.34,
    medianprops={"linewidth": 1.6},
    boxprops={"linewidth": 1.4},
    whiskerprops={"linewidth": 1.4},
    capprops={"linewidth": 1.4},
)
axes[1].axhline(observed_q, linestyle="--", linewidth=1.5)
axes[1].set_ylabel(
    "Heterogeneity statistic Q", fontsize=15.5,
    fontweight="bold", labelpad=9,
)
axes[1].set_xlabel(
    "Forward-simulation input", fontsize=15.5,
    fontweight="bold", labelpad=8,
)
axes[1].set_title("Selection-forward heterogeneity", fontsize=17, pad=10)

for ax in axes:
    ax.tick_params(axis="both", which="major", labelsize=13.5, width=1.2, length=5)
    for label in ax.get_xticklabels() + ax.get_yticklabels():
        label.set_fontweight("bold")

axes[0].set_xlim(-0.55, 2.28)
axes[1].set_ylim(-1.5, 38.5)
fig.subplots_adjust(left=0.145, right=0.985, bottom=0.205, top=0.875, wspace=0.23)
fig.savefig(OUT, bbox_inches="tight", pad_inches=0.06)
plt.close(fig)
print(f"Created {OUT}")
