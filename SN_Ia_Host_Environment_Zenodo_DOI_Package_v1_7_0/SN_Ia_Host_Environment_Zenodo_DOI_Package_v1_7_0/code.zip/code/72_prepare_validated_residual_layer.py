#!/usr/bin/env python
# -*- coding: utf-8 -*-
r"""Prepare and validate the object-level ZTF residual layer needed for Phase 3.

The supplied upstream input must reproduce the frozen ZTF global mass-step result:
    Delta_M = -0.0751448
    SE      =  0.0084868
using WLS with predictors x1, c, and H = I(host_logmass >= 10), with the
covariance scaled by the diagnostic reduced chi-square.

Example
-------
python code/72_prepare_validated_residual_layer.py ^
  --source "data/diagnostic_layers/upstream_residual_standardisation_input.csv" ^
  --outdir "rerun_phase3_input"
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd


TARGET_STEP = -0.07514480293276318
TARGET_SE = 0.0084868
STEP_TOL = 5.0e-5
SE_TOL = 5.0e-5
TARGET_N = 2642


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", required=True, help="Upstream object-level residual-standardisation CSV.")
    parser.add_argument("--outdir", required=True, help="Output directory.")
    return parser.parse_args()


def pick_column(df: pd.DataFrame, names: list[str], required: bool = True) -> str | None:
    lower = {str(col).lower(): str(col) for col in df.columns}
    for name in names:
        if name in df.columns:
            return name
        if name.lower() in lower:
            return lower[name.lower()]
    if required:
        raise ValueError(
            f"Missing required column. Tried {names}. "
            f"Available columns: {list(df.columns)}"
        )
    return None


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def fit_wls(data: pd.DataFrame) -> dict[str, float | int]:
    d = data[
        ["residual", "residual_err", "x1", "c", "host_logmass"]
    ].replace([np.inf, -np.inf], np.nan).dropna().copy()

    d = d[(d["residual_err"] > 0) & (d["z"].notna())] if "z" in d else d
    d["H"] = (d["host_logmass"] >= 10.0).astype(float)

    y = d["residual"].to_numpy(float)
    X = np.column_stack(
        [
            np.ones(len(d)),
            d["x1"].to_numpy(float),
            d["c"].to_numpy(float),
            d["H"].to_numpy(float),
        ]
    )
    err = d["residual_err"].to_numpy(float)
    weight = 1.0 / np.maximum(err, 1.0e-4) ** 2
    sqrt_weight = np.sqrt(weight)
    Xw = X * sqrt_weight[:, None]
    yw = y * sqrt_weight

    beta, *_ = np.linalg.lstsq(Xw, yw, rcond=None)
    residual = y - X @ beta
    n = len(y)
    k = X.shape[1]
    dof = n - k
    chi2_value = float(np.sum(weight * residual**2))
    chi2_red = chi2_value / dof
    covariance = np.linalg.pinv(Xw.T @ Xw) * chi2_red
    standard_error = np.sqrt(np.diag(covariance))

    return {
        "n": int(n),
        "k": int(k),
        "dof": int(dof),
        "intercept": float(beta[0]),
        "x1_coefficient": float(beta[1]),
        "c_coefficient": float(beta[2]),
        "mass_step": float(beta[3]),
        "mass_step_se": float(standard_error[3]),
        "chi2": chi2_value,
        "chi2_red": float(chi2_red),
        "rms": float(np.sqrt(np.mean(residual**2))),
    }


def main() -> None:
    args = parse_args()
    source = Path(args.source).expanduser().resolve()
    outdir = Path(args.outdir).expanduser().resolve()

    if not source.exists():
        raise FileNotFoundError(source)

    processed_dir = outdir / "data" / "processed"
    table_dir = outdir / "results" / "tables"
    doc_dir = outdir / "docs"
    for directory in (processed_dir, table_dir, doc_dir):
        directory.mkdir(parents=True, exist_ok=True)

    raw = pd.read_csv(source)

    mapping = {
        "snid": pick_column(raw, ["snid", "SNID", "CID", "name", "object_id"], required=False),
        "z": pick_column(raw, ["z", "zCMB", "zHD", "zcmb"]),
        "host_logmass": pick_column(raw, ["host_logmass", "HOST_LOGMASS", "logmass"]),
        "residual": pick_column(raw, ["residual", "MURES", "HR", "hubble_residual"]),
        "residual_err": pick_column(
            raw,
            ["residual_err", "MURES_ERR", "MUERR", "MUERR_FINAL", "hr_err"],
        ),
        "x1": pick_column(raw, ["x1", "X1"]),
        "c": pick_column(raw, ["c", "C"]),
        "local_color": pick_column(raw, ["local_color", "LOCAL_COLOR"], required=False),
        "host_dlr": pick_column(raw, ["host_dlr", "HOST_DLR", "HOST_DDLR"], required=False),
        "log1p_host_dlr": pick_column(raw, ["log1p_host_dlr"], required=False),
    }

    clean = pd.DataFrame(index=raw.index)
    if mapping["snid"] is not None:
        clean["snid"] = raw[mapping["snid"]].astype(str)
    else:
        clean["snid"] = [f"row_{index:05d}" for index in range(len(raw))]

    for target in [
        "z",
        "host_logmass",
        "residual",
        "residual_err",
        "x1",
        "c",
        "local_color",
        "host_dlr",
        "log1p_host_dlr",
    ]:
        source_column = mapping[target]
        if source_column is None:
            clean[target] = np.nan
        else:
            clean[target] = pd.to_numeric(raw[source_column], errors="coerce")

    if clean["log1p_host_dlr"].isna().all() and clean["host_dlr"].notna().any():
        clean["log1p_host_dlr"] = np.log1p(clean["host_dlr"])

    clean = clean.replace([np.inf, -np.inf], np.nan)
    clean = clean[
        clean[
            ["z", "host_logmass", "residual", "residual_err", "x1", "c"]
        ].notna().all(axis=1)
    ].copy()
    clean = clean[
        (clean["z"] > 0)
        & (clean["z"] < 0.2)
        & (clean["residual_err"] > 0)
    ].copy()
    clean["mass_step"] = (clean["host_logmass"] >= 10.0).astype(int)
    clean = clean.sort_values(["z", "snid"]).reset_index(drop=True)

    fit = fit_wls(clean)
    fit["target_n"] = TARGET_N
    fit["target_mass_step"] = TARGET_STEP
    fit["target_mass_step_se"] = TARGET_SE
    fit["absolute_step_difference"] = abs(float(fit["mass_step"]) - TARGET_STEP)
    fit["absolute_se_difference"] = abs(float(fit["mass_step_se"]) - TARGET_SE)
    fit["n_matches"] = int(fit["n"]) == TARGET_N
    fit["step_matches"] = float(fit["absolute_step_difference"]) <= STEP_TOL
    fit["se_matches"] = float(fit["absolute_se_difference"]) <= SE_TOL
    fit["validated"] = bool(
        fit["n_matches"] and fit["step_matches"] and fit["se_matches"]
    )

    pd.DataFrame([fit]).to_csv(
        table_dir / "validated_residual_layer_check.csv",
        index=False,
    )

    if not fit["validated"]:
        report = [
            "# Validation failed",
            "",
            f"Source: `{source}`",
            f"Rows used: {fit['n']} (target {TARGET_N})",
            f"Mass step: {fit['mass_step']:.10f} (target {TARGET_STEP:.10f})",
            f"SE: {fit['mass_step_se']:.10f} (target {TARGET_SE:.10f})",
            "",
            "This file was not exported as the frozen validated residual layer.",
        ]
        (doc_dir / "VALIDATION_REPORT.md").write_text(
            "\n".join(report),
            encoding="utf-8",
        )
        raise RuntimeError(
            "The supplied upstream file does not reproduce the frozen ZTF coefficient. "
            f"See {doc_dir / 'VALIDATION_REPORT.md'}"
        )

    output_file = processed_dir / "ZTF_DR2_validated_residual_layer.csv"
    clean.to_csv(output_file, index=False)

    manifest = {
        "source_path": str(source),
        "output_path": str(output_file),
        "source_sha256": sha256(source),
        "output_sha256": sha256(output_file),
        "column_mapping": mapping,
        "validation": fit,
    }
    (doc_dir / "validated_residual_layer_manifest.json").write_text(
        json.dumps(manifest, indent=2),
        encoding="utf-8",
    )

    report = [
        "# Validated ZTF residual-layer recovery",
        "",
        f"- Source: `{source}`",
        f"- Rows: {fit['n']}",
        f"- Recovered mass step: {fit['mass_step']:.10f}",
        f"- Recovered standard error: {fit['mass_step_se']:.10f}",
        f"- Diagnostic reduced chi-square: {fit['chi2_red']:.6f}",
        f"- Output: `{output_file}`",
        f"- Output SHA256: `{manifest['output_sha256']}`",
        "",
        "Status: PASS",
    ]
    (doc_dir / "VALIDATION_REPORT.md").write_text(
        "\n".join(report),
        encoding="utf-8",
    )

    print("Validated residual layer prepared successfully.")
    print(f"Source: {source}")
    print(f"Output: {output_file}")
    print(
        "Recovered mass step: "
        f"{fit['mass_step']:.10f} +/- {fit['mass_step_se']:.10f}"
    )


if __name__ == "__main__":
    main()
