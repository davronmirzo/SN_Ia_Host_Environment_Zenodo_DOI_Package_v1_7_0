# Analysis code

The numbered scripts reproduce the post-ingestion audit sequence from the
canonical processed layers included in this release.

1. `70_q1_strengthening_phase1_audits.py` — completeness, missingness,
   threshold, binning, low-redshift, and hierarchical audits.
2. `71_selection_stress_heterogeneity_Q.py` — selection-forward heterogeneity
   under zero, constant, and tomographic inputs.
3. `72_prepare_validated_residual_layer.py` — integrity-validation helper for an upstream
   residual-standardisation table. The canonical validated layer is already included.
4. `73_object_level_jackknife_influence.py` — deletion, leverage, residual, and
   influence diagnostics.
5. `74_environment_stratification_interaction.py` — stratification, bootstrap,
   permutation, redshift-stability, and availability weighting.
6. `75_external_product_common_support_influence.py` — reduced Pantheon+ and
   DES-SN5YR robustness, support, and separability audit.
7. `76_statistical_calibration_audit.py` — nominal and unit-scale-floor
   calibration of the five-bin meta-regression.
8. `make_fig01_correction_validity_workflow.py` and `.m` — reproducible Figure 1
   sources in Python and MATLAB.
9. `make_fig04_selection_forward_validation.py` — fast regeneration of the final Figure 4 from frozen canonical draws.
10. `make_population_drift_figure.py` — population-drift figure helper.

The package begins from processed survey products. It does not reproduce
upstream cadence, targeting, classification, host association, or
collaboration-level bias-correction pipelines.
