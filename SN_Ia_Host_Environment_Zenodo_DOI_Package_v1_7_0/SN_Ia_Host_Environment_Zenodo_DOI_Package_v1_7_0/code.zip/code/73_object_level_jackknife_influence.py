#!/usr/bin/env python
# -*- coding: utf-8 -*-
r"""Run the Phase-3 observation-level jackknife and influence audit.

Windows example
---------------
python code/73_object_level_jackknife_influence.py ^
  --input "data\processed\ZTF_DR2_validated_residual_layer.csv" ^
  --outdir "phase3_output"
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import chi2, t as student_t


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--outdir", required=True)
    return parser.parse_args()


def fit_wls(frame: pd.DataFrame) -> dict[str, object]:
    y = frame["residual"].to_numpy(float)
    error = frame["residual_err"].to_numpy(float)
    X = np.column_stack(
        [
            np.ones(len(frame)),
            frame["x1"].to_numpy(float),
            frame["c"].to_numpy(float),
            frame["H"].to_numpy(float),
        ]
    )
    weight = 1.0 / np.maximum(error, 1.0e-4) ** 2
    A = X.T @ (weight[:, None] * X)
    b = X.T @ (weight * y)
    A_inverse = np.linalg.pinv(A)
    beta = A_inverse @ b
    residual = y - X @ beta
    sse = float(np.sum(weight * residual**2))
    n = len(y)
    k = X.shape[1]
    dof = n - k
    mse = sse / dof
    covariance = A_inverse * mse
    return {
        "X": X,
        "weight": weight,
        "A_inverse": A_inverse,
        "beta": beta,
        "residual": residual,
        "sse": sse,
        "n": n,
        "k": k,
        "dof": dof,
        "mse": mse,
        "standard_error": np.sqrt(np.diag(covariance)),
    }


def summarize_tomography(
    steps: np.ndarray,
    errors: np.ndarray,
    medians: np.ndarray,
) -> dict[str, float]:
    weight = 1.0 / errors**2
    mean_step = float(np.sum(weight * steps) / np.sum(weight))
    q_value = float(np.sum(weight * (steps - mean_step) ** 2))
    q_probability = float(chi2.sf(q_value, len(steps) - 1))
    design = np.column_stack(
        [np.ones(len(medians)), medians - np.mean(medians)]
    )
    sqrt_weight = np.sqrt(weight)
    weighted_design = design * sqrt_weight[:, None]
    beta, *_ = np.linalg.lstsq(
        weighted_design,
        steps * sqrt_weight,
        rcond=None,
    )
    residual = steps - design @ beta
    dof = len(steps) - 2
    weighted_sse = float(np.sum(weight * residual**2))
    covariance = (
        np.linalg.pinv(weighted_design.T @ weighted_design)
        * (weighted_sse / dof)
    )
    slope = float(beta[1])
    slope_error = float(np.sqrt(covariance[1, 1]))
    slope_probability = float(
        2.0 * student_t.sf(abs(slope / slope_error), dof)
    )
    return {
        "inverse_variance_mean_step": mean_step,
        "heterogeneity_Q": q_value,
        "heterogeneity_p": q_probability,
        "tomography_slope": slope,
        "tomography_slope_se": slope_error,
        "tomography_slope_p_t": slope_probability,
        "step_range": float(np.max(steps) - np.min(steps)),
    }


def main() -> None:
    args = parse_args()
    input_file = Path(args.input).expanduser().resolve()
    outdir = Path(args.outdir).expanduser().resolve()
    table_dir = outdir / "results" / "tables"
    figure_dir = outdir / "figures"
    for directory in (table_dir, figure_dir):
        directory.mkdir(parents=True, exist_ok=True)

    data = pd.read_csv(input_file).reset_index(drop=True)
    data["row_id"] = np.arange(len(data), dtype=int)
    data["object_label"] = data["snid"].astype("object")
    missing = data["object_label"].isna()
    data.loc[missing, "object_label"] = [
        f"row_{row_id:05d}"
        for row_id in data.loc[missing, "row_id"]
    ]
    data["H"] = (data["host_logmass"] >= 10.0).astype(float)

    full = fit_wls(data)
    X = full["X"]
    weight = full["weight"]
    inverse = full["A_inverse"]
    beta = full["beta"]
    residual = full["residual"]
    n = int(full["n"])
    k = int(full["k"])
    mse = float(full["mse"])
    leverage = weight * np.einsum(
        "ij,jk,ik->i", X, inverse, X
    )
    one_minus = 1.0 - leverage
    inverse_x = X @ inverse.T
    beta_deleted = beta[None, :] - (
        inverse_x
        * (weight * residual / one_minus)[:, None]
    )
    deleted_sse = float(full["sse"]) - (
        weight * residual**2 / one_minus
    )
    deleted_mse = deleted_sse / (n - 1 - k)
    deleted_variance = (
        inverse[3, 3]
        + inverse_x[:, 3] ** 2 * weight / one_minus
    )
    deleted_error = np.sqrt(deleted_variance * deleted_mse)
    weighted_residual = np.sqrt(weight) * residual

    influence = pd.DataFrame(
        {
            "row_id": data["row_id"],
            "object_label": data["object_label"],
            "z": data["z"],
            "host_logmass": data["host_logmass"],
            "residual": data["residual"],
            "residual_err": data["residual_err"],
            "leverage": leverage,
            "studentized_residual_external": (
                weighted_residual
                / np.sqrt(deleted_mse * one_minus)
            ),
            "cooks_distance": (
                weighted_residual**2
                / (k * mse)
                * leverage
                / one_minus**2
            ),
            "mass_step_leave_one_out": beta_deleted[:, 3],
            "mass_step_se_leave_one_out": deleted_error,
            "delta_mass_step_leave_one_out_minus_full": (
                beta_deleted[:, 3] - beta[3]
            ),
            "dfbetas_mass_step": (
                beta[3] - beta_deleted[:, 3]
            ) / deleted_error,
        }
    )

    edges = np.quantile(
        data["z"].to_numpy(float),
        np.linspace(0.0, 1.0, 6),
    )
    edges[0] -= 1.0e-10
    edges[-1] += 1.0e-10
    data["zbin"] = pd.cut(
        data["z"],
        bins=edges,
        labels=False,
        include_lowest=True,
    ).astype(int)

    bin_fits = {}
    steps = []
    errors = []
    medians = []
    for bin_index in range(5):
        bin_data = data.loc[data["zbin"] == bin_index].copy()
        bin_fit = fit_wls(bin_data)
        bin_fits[bin_index] = (bin_data, bin_fit)
        steps.append(float(bin_fit["beta"][3]))
        errors.append(float(bin_fit["standard_error"][3]))
        medians.append(float(bin_data["z"].median()))

    steps = np.asarray(steps)
    errors = np.asarray(errors)
    medians = np.asarray(medians)
    baseline = summarize_tomography(steps, errors, medians)

    records = []
    for bin_index in range(5):
        bin_data, bin_fit = bin_fits[bin_index]
        X_bin = bin_fit["X"]
        weight_bin = bin_fit["weight"]
        inverse_bin = bin_fit["A_inverse"]
        beta_bin = bin_fit["beta"]
        residual_bin = bin_fit["residual"]
        leverage_bin = weight_bin * np.einsum(
            "ij,jk,ik->i",
            X_bin,
            inverse_bin,
            X_bin,
        )
        one_minus_bin = 1.0 - leverage_bin
        inverse_x_bin = X_bin @ inverse_bin.T
        beta_deleted_bin = beta_bin[None, :] - (
            inverse_x_bin
            * (
                weight_bin
                * residual_bin
                / one_minus_bin
            )[:, None]
        )
        deleted_sse_bin = float(bin_fit["sse"]) - (
            weight_bin
            * residual_bin**2
            / one_minus_bin
        )
        deleted_mse_bin = deleted_sse_bin / (
            int(bin_fit["n"]) - 1 - int(bin_fit["k"])
        )
        deleted_variance_bin = (
            inverse_bin[3, 3]
            + inverse_x_bin[:, 3] ** 2
            * weight_bin
            / one_minus_bin
        )
        deleted_error_bin = np.sqrt(
            deleted_variance_bin * deleted_mse_bin
        )
        z_values = bin_data["z"].to_numpy(float)
        row_ids = bin_data["row_id"].to_numpy(int)

        for local_index, row_id in enumerate(row_ids):
            current_steps = steps.copy()
            current_errors = errors.copy()
            current_medians = medians.copy()
            current_steps[bin_index] = beta_deleted_bin[
                local_index, 3
            ]
            current_errors[bin_index] = deleted_error_bin[
                local_index
            ]
            current_medians[bin_index] = float(
                np.median(np.delete(z_values, local_index))
            )
            summary = summarize_tomography(
                current_steps,
                current_errors,
                current_medians,
            )
            records.append(
                {
                    "row_id": int(row_id),
                    "redshift_bin": bin_index + 1,
                    "bin_step_leave_one_out": float(
                        current_steps[bin_index]
                    ),
                    "bin_step_se_leave_one_out": float(
                        current_errors[bin_index]
                    ),
                    "delta_bin_step_leave_one_out_minus_full": float(
                        current_steps[bin_index]
                        - steps[bin_index]
                    ),
                    "heterogeneity_Q_leave_one_out": summary[
                        "heterogeneity_Q"
                    ],
                    "heterogeneity_p_leave_one_out": summary[
                        "heterogeneity_p"
                    ],
                    "tomography_slope_leave_one_out": summary[
                        "tomography_slope"
                    ],
                    "tomography_slope_se_leave_one_out": summary[
                        "tomography_slope_se"
                    ],
                    "tomography_slope_p_t_leave_one_out": summary[
                        "tomography_slope_p_t"
                    ],
                    "delta_Q_leave_one_out_minus_full": float(
                        summary["heterogeneity_Q"]
                        - baseline["heterogeneity_Q"]
                    ),
                    "delta_tomography_slope_leave_one_out_minus_full": float(
                        summary["tomography_slope"]
                        - baseline["tomography_slope"]
                    ),
                }
            )

    influence = influence.merge(
        pd.DataFrame(records),
        on="row_id",
        how="left",
    )
    influence.to_csv(
        table_dir / "phase3_leave_one_object_out_full.csv",
        index=False,
    )
    influence.reindex(
        influence["cooks_distance"]
        .sort_values(ascending=False)
        .index
    ).head(20).to_csv(
        table_dir / "phase3_top20_global_influence.csv",
        index=False,
    )
    influence.reindex(
        influence[
            "delta_tomography_slope_leave_one_out_minus_full"
        ]
        .abs()
        .sort_values(ascending=False)
        .index
    ).head(20).to_csv(
        table_dir / "phase3_top20_tomography_influence.csv",
        index=False,
    )

    print("Phase-3 jackknife and influence audit completed.")
    print(f"Input: {input_file}")
    print(f"Output: {outdir}")
    print(
        "Global leave-one-out range: "
        f"[{influence['mass_step_leave_one_out'].min():.8f}, "
        f"{influence['mass_step_leave_one_out'].max():.8f}]"
    )
    print(
        "Tomography-slope leave-one-out range: "
        f"[{influence['tomography_slope_leave_one_out'].min():.6f}, "
        f"{influence['tomography_slope_leave_one_out'].max():.6f}]"
    )


if __name__ == "__main__":
    main()
