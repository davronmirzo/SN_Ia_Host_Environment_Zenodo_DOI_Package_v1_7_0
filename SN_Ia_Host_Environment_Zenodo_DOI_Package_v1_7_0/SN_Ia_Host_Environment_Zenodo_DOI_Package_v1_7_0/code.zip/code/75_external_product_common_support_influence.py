from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import textwrap
import zipfile
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import chi2, ks_2samp, t as student_t
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

BASE = Path(__file__).resolve().parents[1]
OUT = BASE / '_phase5_precomputed'
ZIP_OUT = BASE / '_phase5_precomputed.zip'


SEED = 20260721
N_BOOT = 2000
C_LIGHT = 299792.458
H0 = 70.0
OMEGA_M = 0.3
OMEGA_L = 0.7


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def mu_lcdm(z: np.ndarray) -> np.ndarray:
    z = np.asarray(z, dtype=float)
    out = np.full_like(z, np.nan)
    for i, zi in enumerate(z):
        if not np.isfinite(zi) or zi <= 0:
            continue
        grid = np.linspace(0.0, zi, 400)
        ez = np.sqrt(OMEGA_M * (1.0 + grid) ** 3 + OMEGA_L)
        dc = (C_LIGHT / H0) * np.trapezoid(1.0 / ez, grid)
        dl = (1.0 + zi) * dc
        out[i] = 5.0 * np.log10(dl) + 25.0
    return out


def prepare_inputs(ztf_file: Path, pp_res_file: Path, pp_ana_file: Path, des_file: Path):
    ztf = pd.read_csv(ztf_file).copy()
    ztf = ztf.rename(columns={'residual': 'y', 'residual_err': 'yerr'})
    ztf['dataset'] = 'ZTF_DR2'
    ztf['object_id'] = ztf['snid'].astype(str)
    ztf['H'] = (ztf['host_logmass'] >= 10.0).astype(float)
    ztf['mass_c10'] = ztf['host_logmass'] - 10.0

    pp_res = pd.read_csv(pp_res_file).copy()
    pp_ana = pd.read_csv(pp_ana_file).copy()
    if len(pp_res) != len(pp_ana):
        raise ValueError('Pantheon+ residual and analysis tables differ in length.')
    if not np.all(pp_res['snid'].astype(str).to_numpy() == pp_ana['snid'].astype(str).to_numpy()):
        raise ValueError('Pantheon+ row identities are not aligned.')
    pp = pp_res.rename(columns={'residual': 'y', 'residual_err': 'yerr'}).copy()
    pp['x1'] = pd.to_numeric(pp_ana['x1'], errors='coerce').to_numpy()
    pp['c'] = pd.to_numeric(pp_ana['c'], errors='coerce').to_numpy()
    pp['survey'] = pp_ana['survey'].astype(str).to_numpy()
    pp['dataset'] = 'PantheonPlus'
    pp['object_id'] = [f'{sn}|{sv}|row{i}' for i, (sn, sv) in enumerate(zip(pp['snid'].astype(str), pp['survey']))]
    pp['H'] = (pp['host_logmass'] >= 10.0).astype(float)
    pp['mass_c10'] = pp['host_logmass'] - 10.0

    raw = pd.read_csv(des_file).copy()
    des = pd.DataFrame({
        'object_id': raw['CID'].astype(str),
        'z': pd.to_numeric(raw['zCMB'], errors='coerce'),
        'host_logmass': pd.to_numeric(raw['HOST_LOGMASS'], errors='coerce'),
        'x1': pd.to_numeric(raw['x1'], errors='coerce'),
        'c': pd.to_numeric(raw['c'], errors='coerce'),
        'yerr': pd.to_numeric(raw['MUERR_FINAL'], errors='coerce'),
        'mu': pd.to_numeric(raw['MU'], errors='coerce'),
    })
    des['y'] = des['mu'] - mu_lcdm(des['z'].to_numpy(float))
    des['dataset'] = 'DES_SN5YR'
    des['H'] = (des['host_logmass'] >= 10.0).astype(float)
    des['mass_c10'] = des['host_logmass'] - 10.0
    return ztf, pp, des


def fit_wls(frame: pd.DataFrame, predictors: list[str]):
    required = ['y', 'yerr'] + predictors
    d = frame[required].replace([np.inf, -np.inf], np.nan).dropna().copy()
    y = d['y'].to_numpy(float)
    err = d['yerr'].to_numpy(float)
    X = np.column_stack([np.ones(len(d))] + [d[p].to_numpy(float) for p in predictors])
    names = ['Intercept'] + predictors
    weight = 1.0 / np.maximum(err, 1.0e-5) ** 2
    sqrt_w = np.sqrt(weight)
    Xw = X * sqrt_w[:, None]
    yw = y * sqrt_w
    beta, *_ = np.linalg.lstsq(Xw, yw, rcond=None)
    residual = y - X @ beta
    n = len(y)
    k = X.shape[1]
    dof = n - k
    sse = float(np.sum(weight * residual**2))
    mse = sse / dof
    inverse = np.linalg.pinv(Xw.T @ Xw)
    covariance = inverse * mse
    standard_error = np.sqrt(np.diag(covariance))
    probability = 2.0 * student_t.sf(np.abs(beta / standard_error), dof)
    return {
        'data': d,
        'X': X,
        'y': y,
        'err': err,
        'weight': weight,
        'beta': beta,
        'residual': residual,
        'n': n,
        'k': k,
        'dof': dof,
        'sse': sse,
        'mse': mse,
        'inverse': inverse,
        'covariance': covariance,
        'standard_error': standard_error,
        'probability': probability,
        'names': names,
    }


def coefficient(fit, term: str):
    j = fit['names'].index(term)
    return float(fit['beta'][j]), float(fit['standard_error'][j]), float(fit['probability'][j])


def equal_edges(z: np.ndarray, nbin: int):
    edges = np.quantile(np.asarray(z, float), np.linspace(0.0, 1.0, nbin + 1))
    edges[0] -= 1.0e-10
    edges[-1] += 1.0e-10
    return edges


def tomography_summary(steps, errors, z_median):
    steps = np.asarray(steps, float)
    errors = np.asarray(errors, float)
    z_median = np.asarray(z_median, float)
    weights = 1.0 / errors**2
    mean_step = float(np.sum(weights * steps) / np.sum(weights))
    q_value = float(np.sum(weights * (steps - mean_step) ** 2))
    q_probability = float(chi2.sf(q_value, len(steps) - 1))

    design = np.column_stack([np.ones(len(z_median)), z_median - np.mean(z_median)])
    sqrt_w = np.sqrt(weights)
    design_w = design * sqrt_w[:, None]
    beta, *_ = np.linalg.lstsq(design_w, steps * sqrt_w, rcond=None)
    residual = steps - design @ beta
    dof = len(steps) - 2
    scale = float(np.sum(weights * residual**2) / dof)
    inverse = np.linalg.pinv(design_w.T @ design_w)
    covariance = inverse * scale
    slope = float(beta[1])
    slope_se = float(np.sqrt(covariance[1, 1]))
    slope_p = float(2.0 * student_t.sf(abs(slope / slope_se), dof))
    floor_covariance = inverse * max(scale, 1.0)
    floor_se = float(np.sqrt(floor_covariance[1, 1]))
    floor_p = float(2.0 * student_t.sf(abs(slope / floor_se), dof))
    return {
        'inverse_variance_mean_step': mean_step,
        'heterogeneity_Q': q_value,
        'heterogeneity_p': q_probability,
        'tomography_slope': slope,
        'tomography_slope_se': slope_se,
        'tomography_slope_p_t': slope_p,
        'tomography_slope_se_unit_floor': floor_se,
        'tomography_slope_p_unit_floor': floor_p,
        'step_range': float(np.max(steps) - np.min(steps)),
    }


def tomography(frame: pd.DataFrame, base_predictors: list[str], nbin=5, edges=None):
    required = ['z', 'y', 'yerr', 'host_logmass'] + base_predictors
    d = frame.replace([np.inf, -np.inf], np.nan).dropna(subset=required).copy()
    if edges is None:
        edges = equal_edges(d['z'].to_numpy(float), nbin)
    d['zbin'] = pd.cut(d['z'], bins=edges, labels=False, include_lowest=True)
    rows = []
    for b in range(nbin):
        bd = d.loc[d['zbin'] == b].copy()
        if len(bd) < len(base_predictors) + 5:
            raise ValueError(f'Insufficient rows in bin {b + 1}.')
        fit = fit_wls(bd, base_predictors + ['H'])
        estimate, error, probability = coefficient(fit, 'H')
        rows.append({
            'bin': b + 1,
            'n': len(bd),
            'z_min': float(bd['z'].min()),
            'z_max': float(bd['z'].max()),
            'z_median': float(bd['z'].median()),
            'mass_step': estimate,
            'mass_step_se': error,
            'mass_step_p': probability,
        })
    bins = pd.DataFrame(rows)
    summary = tomography_summary(bins['mass_step'], bins['mass_step_se'], bins['z_median'])
    return bins, summary, np.asarray(edges), d


def global_summary(frame, base_predictors, dataset_key, product_role, estimator):
    step_fit = fit_wls(frame, base_predictors + ['H'])
    mass_fit = fit_wls(frame, base_predictors + ['mass_c10'])
    step, step_se, step_p = coefficient(step_fit, 'H')
    slope, slope_se, slope_p = coefficient(mass_fit, 'mass_c10')
    bins, tomo, _, _ = tomography(frame, base_predictors, 5)
    row = {
        'dataset': dataset_key,
        'product_role': product_role,
        'estimator': estimator,
        'n': int(step_fit['n']),
        'global_step': step,
        'global_step_se': step_se,
        'global_step_p': step_p,
        'continuous_mass_slope': slope,
        'continuous_mass_slope_se': slope_se,
        'continuous_mass_slope_p': slope_p,
        **tomo,
    }
    bins.insert(0, 'dataset', dataset_key)
    bins.insert(1, 'estimator', estimator)
    return row, bins


def exact_loo_audit(frame, base_predictors, dataset_key, estimator):
    required = ['object_id', 'z', 'host_logmass', 'y', 'yerr', 'H'] + base_predictors
    d = frame.replace([np.inf, -np.inf], np.nan).dropna(subset=required).copy().reset_index(drop=True)
    d['row_id'] = np.arange(len(d), dtype=int)

    full = fit_wls(d, base_predictors + ['H'])
    X = full['X']
    w = full['weight']
    inv = full['inverse']
    residual = full['residual']
    beta = full['beta']
    n = full['n']
    k = full['k']
    leverage = w * np.einsum('ij,jk,ik->i', X, inv, X)
    one_minus = 1.0 - leverage
    inv_x = X @ inv.T
    beta_deleted = beta[None, :] - inv_x * (w * residual / one_minus)[:, None]
    sse_deleted = full['sse'] - w * residual**2 / one_minus
    mse_deleted = sse_deleted / (n - 1 - k)
    j = full['names'].index('H')
    variance_factor = inv[j, j] + inv_x[:, j] ** 2 * w / one_minus
    se_deleted = np.sqrt(variance_factor * mse_deleted)

    bins, baseline, edges, d_with_bins = tomography(d, base_predictors, 5)
    records = []
    for b in range(5):
        bd = d_with_bins.loc[d_with_bins['zbin'] == b].copy().reset_index()
        fit = fit_wls(bd, base_predictors + ['H'])
        Xb = fit['X']
        wb = fit['weight']
        invb = fit['inverse']
        rb = fit['residual']
        hb = wb * np.einsum('ij,jk,ik->i', Xb, invb, Xb)
        one_minus_b = 1.0 - hb
        inv_x_b = Xb @ invb.T
        beta_deleted_b = fit['beta'][None, :] - inv_x_b * (wb * rb / one_minus_b)[:, None]
        sse_deleted_b = fit['sse'] - wb * rb**2 / one_minus_b
        mse_deleted_b = sse_deleted_b / (fit['n'] - 1 - fit['k'])
        jb = fit['names'].index('H')
        var_b = invb[jb, jb] + inv_x_b[:, jb] ** 2 * wb / one_minus_b
        se_deleted_b = np.sqrt(var_b * mse_deleted_b)
        zvals = bd['z'].to_numpy(float)

        for local_index, row in bd.iterrows():
            steps = bins['mass_step'].to_numpy(float).copy()
            errors = bins['mass_step_se'].to_numpy(float).copy()
            medians = bins['z_median'].to_numpy(float).copy()
            steps[b] = beta_deleted_b[local_index, jb]
            errors[b] = se_deleted_b[local_index]
            medians[b] = float(np.median(np.delete(zvals, local_index)))
            t = tomography_summary(steps, errors, medians)
            records.append({
                'row_id': int(row['index']),
                'redshift_bin': b + 1,
                'tomography_slope_loo': t['tomography_slope'],
                'tomography_slope_se_loo': t['tomography_slope_se'],
                'tomography_slope_p_loo': t['tomography_slope_p_t'],
                'heterogeneity_Q_loo': t['heterogeneity_Q'],
                'heterogeneity_p_loo': t['heterogeneity_p'],
                'delta_tomography_slope': t['tomography_slope'] - baseline['tomography_slope'],
            })

    tomo_loo = pd.DataFrame(records)
    out = d[['row_id', 'object_id', 'z', 'host_logmass', 'y', 'yerr']].copy()
    out['global_step_loo'] = beta_deleted[:, j]
    out['global_step_se_loo'] = se_deleted
    out['leverage'] = leverage
    out = out.merge(tomo_loo, on='row_id', how='left')
    out.insert(0, 'dataset', dataset_key)
    out.insert(1, 'estimator', estimator)

    baseline_step, baseline_step_se, _ = coefficient(full, 'H')
    summary = {
        'dataset': dataset_key,
        'estimator': estimator,
        'n': len(d),
        'global_step': baseline_step,
        'global_step_se': baseline_step_se,
        'global_step_loo_min': float(out['global_step_loo'].min()),
        'global_step_loo_max': float(out['global_step_loo'].max()),
        'global_step_all_same_sign': bool((out['global_step_loo'] < 0).all()) if baseline_step < 0 else bool((out['global_step_loo'] > 0).all()),
        'tomography_slope': baseline['tomography_slope'],
        'tomography_slope_se': baseline['tomography_slope_se'],
        'tomography_slope_p': baseline['tomography_slope_p_t'],
        'tomography_slope_loo_min': float(out['tomography_slope_loo'].min()),
        'tomography_slope_loo_max': float(out['tomography_slope_loo'].max()),
        'tomography_slope_p_loo_min': float(out['tomography_slope_p_loo'].min()),
        'tomography_slope_p_loo_max': float(out['tomography_slope_p_loo'].max()),
        'tomography_slope_all_same_sign': bool((out['tomography_slope_loo'] > 0).all()) if baseline['tomography_slope'] > 0 else bool((out['tomography_slope_loo'] < 0).all()),
        'heterogeneity_Q': baseline['heterogeneity_Q'],
        'heterogeneity_p': baseline['heterogeneity_p'],
        'heterogeneity_Q_loo_min': float(out['heterogeneity_Q_loo'].min()),
        'heterogeneity_Q_loo_max': float(out['heterogeneity_Q_loo'].max()),
        'heterogeneity_p_loo_min': float(out['heterogeneity_p_loo'].min()),
        'heterogeneity_p_loo_max': float(out['heterogeneity_p_loo'].max()),
    }
    return out, summary


def binning_grid(frame, base_predictors, dataset_key, estimator):
    required = ['z', 'y', 'yerr', 'host_logmass', 'H'] + base_predictors
    d = frame.replace([np.inf, -np.inf], np.nan).dropna(subset=required).copy()
    rows = []
    for mode in ['equal_number', 'fixed_width']:
        for nbin in range(3, 7):
            edges = None if mode == 'equal_number' else np.linspace(float(d['z'].min()) - 1e-10, float(d['z'].max()) + 1e-10, nbin + 1)
            try:
                bins, summary, _, _ = tomography(d, base_predictors, nbin, edges)
                rows.append({
                    'dataset': dataset_key,
                    'estimator': estimator,
                    'binning': mode,
                    'n_bin': nbin,
                    **summary,
                    'status': 'ok',
                })
            except Exception as exc:
                rows.append({
                    'dataset': dataset_key,
                    'estimator': estimator,
                    'binning': mode,
                    'n_bin': nbin,
                    'status': f'not_estimable: {exc}',
                })
    return pd.DataFrame(rows)


def bootstrap_audit(frame, base_predictors, dataset_key, estimator, n_boot, seed):
    required = ['z', 'y', 'yerr', 'host_logmass', 'H'] + base_predictors
    d = frame.replace([np.inf, -np.inf], np.nan).dropna(subset=required).copy().reset_index(drop=True)
    z = d['z'].to_numpy(float)
    y = d['y'].to_numpy(float)
    err = d['yerr'].to_numpy(float)
    H = d['H'].to_numpy(float)
    base = [d[p].to_numpy(float) for p in base_predictors]
    n = len(d)
    fixed_edges = equal_edges(z, 5)
    rng = np.random.default_rng(seed)

    def one_draw(index, mode):
        zs = z[index]
        ys = y[index]
        es = err[index]
        hs = H[index]
        xs = [arr[index] for arr in base]
        edges = fixed_edges if mode == 'fixed_edges' else equal_edges(zs, 5)
        labels = np.searchsorted(edges, zs, side='right') - 1
        labels = np.clip(labels, 0, 4)
        steps = np.empty(5, float)
        step_errors = np.empty(5, float)
        medians = np.empty(5, float)
        for b in range(5):
            mask = labels == b
            if mask.sum() < len(base_predictors) + 5:
                raise ValueError('insufficient bootstrap bin')
            X = np.column_stack([np.ones(mask.sum())] + [x[mask] for x in xs] + [hs[mask]])
            yy = ys[mask]
            ww = 1.0 / np.maximum(es[mask], 1e-5) ** 2
            normal = X.T @ (ww[:, None] * X)
            inv = np.linalg.pinv(normal)
            beta = inv @ (X.T @ (ww * yy))
            residual = yy - X @ beta
            dof = mask.sum() - X.shape[1]
            mse = float(np.sum(ww * residual**2) / dof)
            steps[b] = beta[-1]
            step_errors[b] = np.sqrt(inv[-1, -1] * mse)
            medians[b] = np.median(zs[mask])
        return tomography_summary(steps, step_errors, medians)

    records = []
    for mode in ['fixed_edges', 'rebin_equal_number']:
        for draw in range(n_boot):
            index = rng.integers(0, n, size=n)
            try:
                t = one_draw(index, mode)
            except Exception:
                continue
            records.append({
                'dataset': dataset_key,
                'estimator': estimator,
                'mode': mode,
                'draw': draw,
                'tomography_slope': t['tomography_slope'],
                'heterogeneity_Q': t['heterogeneity_Q'],
                'heterogeneity_p': t['heterogeneity_p'],
            })
    draws = pd.DataFrame(records)
    summary_rows = []
    for mode, group in draws.groupby('mode'):
        for quantity in ['tomography_slope', 'heterogeneity_Q']:
            x = group[quantity].dropna().to_numpy(float)
            summary_rows.append({
                'dataset': dataset_key,
                'estimator': estimator,
                'mode': mode,
                'quantity': quantity,
                'n_draw': len(x),
                'median': float(np.median(x)),
                'p16': float(np.percentile(x, 16)),
                'p84': float(np.percentile(x, 84)),
                'p025': float(np.percentile(x, 2.5)),
                'p975': float(np.percentile(x, 97.5)),
                'fraction_positive': float(np.mean(x > 0)),
                'fraction_negative': float(np.mean(x < 0)),
            })
    return draws, pd.DataFrame(summary_rows)

def standardised_mean_difference(a, b):
    a = np.asarray(a, float)
    b = np.asarray(b, float)
    a = a[np.isfinite(a)]
    b = b[np.isfinite(b)]
    pooled = np.sqrt(((len(a) - 1) * a.var(ddof=1) + (len(b) - 1) * b.var(ddof=1)) / (len(a) + len(b) - 2))
    return float((b.mean() - a.mean()) / pooled)


def common_support_audit(ztf, external, external_name):
    variables = [('z', 'z'), ('host_logmass', 'host_logmass'), ('x1', 'x1'), ('c', 'c'), ('log10_yerr', 'yerr')]
    rows = []
    for label, column in variables:
        a = pd.to_numeric(ztf[column], errors='coerce').to_numpy(float)
        b = pd.to_numeric(external[column], errors='coerce').to_numpy(float)
        if label == 'log10_yerr':
            a = np.log10(np.clip(a, 1e-8, None))
            b = np.log10(np.clip(b, 1e-8, None))
        a = a[np.isfinite(a)]
        b = b[np.isfinite(b)]
        ks = ks_2samp(a, b, method='auto')
        aq = np.quantile(a, [0.01, 0.99])
        bq = np.quantile(b, [0.01, 0.99])
        lo = max(aq[0], bq[0])
        hi = min(aq[1], bq[1])
        rows.append({
            'comparison': f'ZTF_vs_{external_name}',
            'variable': label,
            'n_ztf': len(a),
            'n_external': len(b),
            'mean_ztf': float(np.mean(a)),
            'mean_external': float(np.mean(b)),
            'smd_external_minus_ztf': standardised_mean_difference(a, b),
            'abs_smd': abs(standardised_mean_difference(a, b)),
            'ks_D': float(ks.statistic),
            'ks_p': float(ks.pvalue),
            'common_support_lo_1_99pct': float(lo),
            'common_support_hi_1_99pct': float(hi),
            'ztf_fraction_in_common': float(np.mean((a >= lo) & (a <= hi))) if hi > lo else 0.0,
            'external_fraction_in_common': float(np.mean((b >= lo) & (b <= hi))) if hi > lo else 0.0,
        })

    features = ['z', 'host_logmass', 'x1', 'c', 'yerr']
    a = ztf[features].copy()
    b = external[features].copy()
    a['log10_yerr'] = np.log10(np.clip(a['yerr'], 1e-8, None))
    b['log10_yerr'] = np.log10(np.clip(b['yerr'], 1e-8, None))
    use = ['z', 'host_logmass', 'x1', 'c', 'log10_yerr']
    a = a[use].dropna()
    b = b[use].dropna()
    X = pd.concat([a, b], ignore_index=True).to_numpy(float)
    y = np.r_[np.zeros(len(a), dtype=int), np.ones(len(b), dtype=int)]
    classifier = make_pipeline(StandardScaler(), LogisticRegression(max_iter=3000, solver='lbfgs'))
    cv = StratifiedKFold(5, shuffle=True, random_state=SEED)
    auc = cross_val_score(classifier, X, y, cv=cv, scoring='roc_auc')
    classifier_row = {
        'comparison': f'ZTF_vs_{external_name}',
        'n_ztf': len(a),
        'n_external': len(b),
        'classifier_auc_mean': float(np.mean(auc)),
        'classifier_auc_sd': float(np.std(auc, ddof=1)),
    }
    return pd.DataFrame(rows), classifier_row


def make_figures(out_dir: Path, bootstrap_draws: pd.DataFrame, support: pd.DataFrame):
    fig_dir = out_dir / 'figures'
    fig_dir.mkdir(parents=True, exist_ok=True)

    # External bootstrap slope distributions: separate axes in one publication figure.
    fig, axes = plt.subplots(1, 2, figsize=(10.0, 4.1))
    pp = bootstrap_draws[(bootstrap_draws['dataset'] == 'PantheonPlus_reported') & (bootstrap_draws['mode'] == 'fixed_edges')]
    des = bootstrap_draws[(bootstrap_draws['dataset'] == 'DES_SN5YR_full') & (bootstrap_draws['mode'] == 'fixed_edges')]
    axes[0].hist(pp['tomography_slope'], bins=45)
    axes[0].axvline(0.0, linestyle='--', linewidth=1.0)
    axes[0].set_xlabel('Pantheon+ tomography slope')
    axes[0].set_ylabel('Bootstrap draws')
    axes[0].set_title('Pantheon+ final product')
    axes[1].hist(des['tomography_slope'], bins=45)
    axes[1].axvline(0.0, linestyle='--', linewidth=1.0)
    axes[1].set_xlabel('DES-SN5YR tomography slope')
    axes[1].set_ylabel('Bootstrap draws')
    axes[1].set_title('DES-SN5YR corrected HD')
    fig.tight_layout()
    fig.savefig(fig_dir / 'fig_phase5_external_bootstrap_slopes.pdf', bbox_inches='tight')
    fig.savefig(fig_dir / 'fig_phase5_external_bootstrap_slopes.png', dpi=240, bbox_inches='tight')
    plt.close(fig)

    # Common-support absolute SMD values.
    pivot = support.pivot(index='variable', columns='comparison', values='abs_smd').reindex(['z', 'host_logmass', 'x1', 'c', 'log10_yerr'])
    x = np.arange(len(pivot.index))
    width = 0.36
    fig, ax = plt.subplots(figsize=(7.4, 4.6))
    comparisons = list(pivot.columns)
    for i, comparison in enumerate(comparisons):
        ax.bar(x + (i - (len(comparisons)-1)/2) * width, pivot[comparison].to_numpy(float), width=width, label=comparison.replace('ZTF_vs_', ''))
    ax.axhline(0.2, linestyle='--', linewidth=1.0, label='|SMD| = 0.2')
    ax.set_xticks(x)
    ax.set_xticklabels(['redshift', 'host mass', '$x_1$', '$c$', 'log residual error'], rotation=18, ha='right')
    ax.set_ylabel('Absolute standardised mean difference')
    ax.set_title('Common-support diagnostics relative to ZTF DR2')
    ax.legend()
    fig.tight_layout()
    fig.savefig(fig_dir / 'fig_phase5_common_support_smd.pdf', bbox_inches='tight')
    fig.savefig(fig_dir / 'fig_phase5_common_support_smd.png', dpi=240, bbox_inches='tight')
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description='Run the Phase-5 external-product robustness audit.')
    parser.add_argument('--root', default=str(Path(__file__).resolve().parents[1]), help='Extracted Phase-5 package root.')
    parser.add_argument('--outdir', required=True, help='Output directory for regenerated tables and figures.')
    parser.add_argument('--n-bootstrap', type=int, default=2000)
    parser.add_argument('--seed', type=int, default=20260721)
    args = parser.parse_args()

    root = Path(args.root).expanduser().resolve()
    out = Path(args.outdir).expanduser().resolve()
    table_dir = out / 'results' / 'tables'
    figure_dir = out / 'figures'
    table_dir.mkdir(parents=True, exist_ok=True)
    figure_dir.mkdir(parents=True, exist_ok=True)

    source = root / 'data' / 'external_products' / 'source'
    ztf_file = root / 'data' / 'processed' / 'ZTF_DR2_validated_residual_layer.csv'
    pp_res_file = source / 'PantheonPlus_lc_residuals.csv'
    pp_ana_file = root / 'data' / 'processed' / 'PantheonPlus_analysis_sample.csv'
    des_file = source / 'DES-SN5YR_HD+MetaData.csv'
    for path in [ztf_file, pp_res_file, pp_ana_file, des_file]:
        if not path.exists():
            raise FileNotFoundError(path)

    ztf, pp, des = prepare_inputs(ztf_file, pp_res_file, pp_ana_file, des_file)
    zmin = max(float(ztf['z'].min()), float(des['z'].min()))
    zmax = min(float(ztf['z'].max()), float(des['z'].max()))
    des_overlap = des.loc[(des['z'] >= zmin) & (des['z'] <= zmax)].copy()

    configs = [
        ('ZTF_DR2', ztf, ['x1', 'c'], 'primary validated residual', 'x1+c+H'),
        ('PantheonPlus_reported', pp, [], 'homogenised final residual product', 'product-native residual+H'),
        ('PantheonPlus_harmonized_sensitivity', pp, ['x1', 'c'], 'covariate-adjusted sensitivity only', 'residual+x1+c+H'),
        ('DES_SN5YR_full', des, ['x1', 'c'], 'corrected Hubble-diagram product', 'HR+x1+c+H'),
        ('DES_SN5YR_ZTF_z_support', des_overlap, ['x1', 'c'], 'DES restricted to ZTF redshift support', 'HR+x1+c+H'),
    ]

    baseline_rows, bin_rows = [], []
    for key, frame, predictors, role, estimator in configs:
        row, bins = global_summary(frame, predictors, key, role, estimator)
        baseline_rows.append(row)
        bin_rows.append(bins)
    pd.DataFrame(baseline_rows).to_csv(table_dir / 'phase5_external_baseline_summary.csv', index=False)
    pd.concat(bin_rows, ignore_index=True).to_csv(table_dir / 'phase5_external_five_bin_coefficients.csv', index=False)

    grids = [binning_grid(frame, predictors, key, estimator) for key, frame, predictors, role, estimator in configs[1:]]
    pd.concat(grids, ignore_index=True).to_csv(table_dir / 'phase5_external_binning_sensitivity.csv', index=False)

    loo_full_rows, loo_summary_rows, boot_draw_rows, boot_summary_rows = [], [], [], []
    for i, (key, frame, predictors, role, estimator) in enumerate([configs[1], configs[3]]):
        full, summary = exact_loo_audit(frame, predictors, key, estimator)
        loo_full_rows.append(full)
        loo_summary_rows.append(summary)
        draws, boot_summary = bootstrap_audit(frame, predictors, key, estimator, args.n_bootstrap, args.seed + 1000 * (i + 1))
        boot_draw_rows.append(draws)
        boot_summary_rows.append(boot_summary)
    loo_full = pd.concat(loo_full_rows, ignore_index=True)
    loo_summary = pd.DataFrame(loo_summary_rows)
    boot_draws = pd.concat(boot_draw_rows, ignore_index=True)
    boot_summary = pd.concat(boot_summary_rows, ignore_index=True)
    loo_full.to_csv(table_dir / 'phase5_external_leave_one_out_full.csv', index=False)
    loo_summary.to_csv(table_dir / 'phase5_external_leave_one_out_summary.csv', index=False)
    boot_draws.to_csv(table_dir / 'phase5_external_bootstrap_draws.csv', index=False)
    boot_summary.to_csv(table_dir / 'phase5_external_bootstrap_summary.csv', index=False)

    support_rows, auc_rows = [], []
    for name, frame in [('PantheonPlus', pp), ('DES_SN5YR', des)]:
        support, auc = common_support_audit(ztf, frame, name)
        support_rows.append(support)
        auc_rows.append(auc)
    support = pd.concat(support_rows, ignore_index=True)
    separability = pd.DataFrame(auc_rows)
    support.to_csv(table_dir / 'phase5_common_support_smd_ks.csv', index=False)
    separability.to_csv(table_dir / 'phase5_survey_separability.csv', index=False)

    b = pd.DataFrame(baseline_rows)
    overlap = pd.DataFrame([{
        'ztf_z_min': float(ztf.z.min()),
        'ztf_z_max': float(ztf.z.max()),
        'des_full_n': len(des),
        'des_in_ztf_z_support_n': len(des_overlap),
        'des_fraction_in_ztf_z_support': len(des_overlap) / len(des),
        'des_full_tomography_slope': float(b.loc[b.dataset == 'DES_SN5YR_full', 'tomography_slope'].iloc[0]),
        'des_overlap_tomography_slope': float(b.loc[b.dataset == 'DES_SN5YR_ZTF_z_support', 'tomography_slope'].iloc[0]),
    }])
    overlap.to_csv(table_dir / 'phase5_des_ztf_redshift_overlap_summary.csv', index=False)

    make_figures(out, boot_draws, support)
    print('Phase-5 external-product audit completed.')
    print(f'Root: {root}')
    print(f'Output: {out}')


if __name__ == '__main__':
    main()
